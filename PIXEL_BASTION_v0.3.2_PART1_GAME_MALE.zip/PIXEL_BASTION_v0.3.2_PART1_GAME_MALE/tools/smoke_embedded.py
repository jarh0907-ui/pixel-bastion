from playwright.sync_api import sync_playwright
from pathlib import Path
import json,base64,re
r=Path('/mnt/data/PIXEL_BASTION_v030_work')
ht=(r/'index.html').read_text();css=(r/'style.css').read_text();js=(r/'game.js').read_text();cfg=(r/'assets/config.js').read_text()

def datauri(path):
 return 'data:image/png;base64,'+base64.b64encode((r/path).read_bytes()).decode('ascii')
for rel in (['assets/sprites/house_thatch.png']+[str(p.relative_to(r)) for p in (r/'assets/sprites').glob('*.png')]):
 cfg=cfg.replace("'"+rel+"'",'"'+datauri(rel)+'"')
for rel in ['assets/npc/NPC_MALE/male_walk_4dir_3frames.png','assets/npc/NPC_MALE/male_emotes_7poses.png','assets/npc/NPC_MALE/aligned_idle_down.png']:
 js=js.replace("'"+rel+"'",'"'+datauri(rel)+'"')
ht=ht.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
ht=ht.replace('<script defer src="assets/config.js"></script>','').replace('<script defer src="game.js"></script>','')
ht=ht.replace('src="assets/sprites/house_thatch.png"','src="'+datauri('assets/sprites/house_thatch.png')+'"')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
 errs=[]
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('console',lambda m:errs.append('console: '+m.text) if m.type=='error' else None)
 page.set_content(ht,wait_until='load')
 page.add_script_tag(content=cfg)
 page.add_script_tag(content=js)
 page.wait_for_timeout(1200)
 print('INIT:',json.dumps(page.evaluate('PIXEL_BASTION.snapshot()'),ensure_ascii=False)[:1100])
 print('IMAGES:',page.evaluate("({house:document.querySelector('.house-build img').naturalWidth,npc:document.querySelectorAll('[data-pose]').length})"))
 page.screenshot(path='/mnt/data/PIXEL_BASTION_v030_preview.png',full_page=True,timeout=15000)
 # Click resident on canvas, test inspector and controls.
 v=page.evaluate('PIXEL_BASTION.snapshot().villagers[0]')
 pos=page.evaluate('''(v)=>{ const c=document.getElementById('gameCanvas').getBoundingClientRect(),z=.94;
    return {x:((v.x-1680)*z+480)/960*c.width, y:((v.y-36-1680)*z+288)/576*c.height}; }''',v)
 page.locator('#gameCanvas').click(position=pos)
 print('NPC CLICK:',page.locator('#inspector').inner_text()[:130])
 print('POSE BUTTONS:',page.locator('[data-pose]').count())
 if page.locator('[data-pose="thinking"]').count():
  page.locator('[data-pose="thinking"]').click()
 print('AFTER THINK:',page.evaluate('PIXEL_BASTION.snapshot().villagers[0].action'))
 print('START GROWTH:',page.evaluate('PIXEL_BASTION.snapshot().population'))
 page.wait_for_timeout(12700)
 print('AFTER GROWTH:',page.evaluate('PIXEL_BASTION.snapshot().population'))
 test=page.evaluate('''() => {
   const spots=[];
   for(let y=1200;y<2200;y+=100){ for(let x=1200;x<2200;x+=100){
     if(PIXEL_BASTION.snapshot().houseCount<3&&PIXEL_BASTION.buildHouse(x,y))spots.push([x,y]);
   } }
   return {spots,houseCount:PIXEL_BASTION.snapshot().houseCount};
 }''')
 print('BUILT:',test)
 print('4TH:',page.evaluate('PIXEL_BASTION.buildHouse(2050,2050)'))
 print('POSE:',page.evaluate("PIXEL_BASTION.poseVillager(1,'happy')"))
 print('NPC:',page.evaluate('PIXEL_BASTION.snapshot().villagers'))
 page.wait_for_timeout(300)
 page.screenshot(path='/mnt/data/PIXEL_BASTION_v030_three_homes.png',full_page=True,timeout=15000)
 page.evaluate('PIXEL_BASTION.reset()')
 print('RESET:',json.dumps(page.evaluate('PIXEL_BASTION.snapshot()'),ensure_ascii=False)[:700])
 print('TOWER:',page.evaluate("PIXEL_BASTION.place('arrow',1810,1930)"))
 page.evaluate('PIXEL_BASTION.startWave()')
 page.wait_for_timeout(1400)
 print('WAVE:',json.dumps(page.evaluate('PIXEL_BASTION.snapshot()'),ensure_ascii=False)[:1000])
 page.set_viewport_size({'width':390,'height':844})
 page.screenshot(path='/mnt/data/PIXEL_BASTION_v030_mobile.png',full_page=True,timeout=15000)
 print('JS ERRORS:',errs[:20])
 b.close()
