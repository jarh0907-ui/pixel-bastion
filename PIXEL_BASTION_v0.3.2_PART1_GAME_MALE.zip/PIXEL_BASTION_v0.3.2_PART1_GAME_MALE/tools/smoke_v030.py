from playwright.sync_api import sync_playwright
from subprocess import Popen,DEVNULL
import time,json
srv=Popen(['python','-m','http.server','8765','--bind','127.0.0.1'],cwd='/mnt/data/PIXEL_BASTION_v030_work',stdout=DEVNULL,stderr=DEVNULL)
try:
 time.sleep(.6)
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('console',lambda m:errors.append('console: '+m.text) if m.type=='error' else None)
  page.goto('file:///mnt/data/PIXEL_BASTION_v030_work/index.html',wait_until='networkidle',timeout=25000)
  page.wait_for_timeout(1500)
  print('AT LOAD:',json.dumps(page.evaluate('PIXEL_BASTION.snapshot()'),ensure_ascii=False)[:1500])
  print('Images:',page.evaluate("({house:document.querySelector('.house-build img').naturalWidth,npc:document.querySelectorAll('[data-pose]').length})"))
  page.screenshot(path='/mnt/data/PIXEL_BASTION_v030_preview.png',full_page=True)
  # test house at possible plot locations
  test=page.evaluate('''() => { const positions=[];
    for(let y=1200;y<2200;y+=120) for(let x=1200;x<2200;x+=120) {
      const before=PIXEL_BASTION.snapshot().houseCount;
      if(PIXEL_BASTION.buildHouse(x,y)) positions.push([x,y]);
      if(PIXEL_BASTION.snapshot().houseCount>=3)break;
    }
    const snap=PIXEL_BASTION.snapshot();return{positions,houseCount:snap.houseCount,capacity:snap.populationCapacity};
  }''')
  print('House placement:',test)
  print('after 3:',page.evaluate('PIXEL_BASTION.snapshot()'))
  print('4th house result:',page.evaluate('PIXEL_BASTION.buildHouse(2050,2050)'))
  print('NPC pose result:',page.evaluate("PIXEL_BASTION.poseVillager(1,'happy')"))
  page.wait_for_timeout(500)
  print('NPC action:',page.evaluate('PIXEL_BASTION.snapshot().villagers'))
  page.screenshot(path='/mnt/data/PIXEL_BASTION_v030_three_homes.png',full_page=True)
  # reset and test gameplay unaffected
  page.evaluate('PIXEL_BASTION.reset()')
  print('reset:',page.evaluate('PIXEL_BASTION.snapshot()'))
  print('tower placed:',page.evaluate("PIXEL_BASTION.place('arrow',1810,1930)"))
  page.evaluate('PIXEL_BASTION.startWave()')
  page.wait_for_timeout(2000)
  print('wave:',page.evaluate('PIXEL_BASTION.snapshot()'))
  print('JS ERRORS',errors)
  browser.close()
finally:
 srv.terminate();srv.wait(timeout=5)
