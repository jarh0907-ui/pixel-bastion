"""PIXEL BASTION v0.2.0: reproducible pixel-art reference assets, pure Pillow.
Native-resolution hard pixels. No interpolation or third-party downloaded art.
"""
from PIL import Image, ImageDraw
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent.parent / 'assets' / 'sprites'
ROOT.mkdir(parents=True, exist_ok=True)
OUT='#25313d'; DARK='#3b4550'; STONE='#657888'; LIGHT='#a5b3ac'; WHITE='#e9dfbc'; GOLD='#e9c371'


def save(name, image): image.save(ROOT/(name+'.png'))

def r(draw,xy,color, outline=None, width=1): draw.rectangle(xy,fill=color,outline=outline,width=width)
def poly(draw,xy,color,outline=None,width=1): draw.polygon(xy,fill=color); draw.line(xy+[xy[0]],fill=outline,width=width) if outline else None

def brick(draw,x1,y1,x2,y2,seed=1):
    rnd=random.Random(seed)
    for y in range(y1+7,y2-3,8):
        x=x1 + (4 if (y//8)%2 else 0)
        while x < x2-4:
            w=rnd.choice([9,12,14])
            draw.line((x,y,x+w,y),fill='#4d6370',width=1)
            if rnd.random()<.46: r(draw,(x+2,y-3,min(x+w-2,x2-3),y-2),rnd.choice(['#80919b','#87989a','#6e8292']))
            x+=w+3

def canvas(sz):return Image.new('RGBA',sz,(0,0,0,0))

def tower(name):
    im=canvas((96,112));d=ImageDraw.Draw(im)
    # Ground contact and stone plinth.
    d.ellipse((15,91,84,108),fill=(13,20,20,93))
    poly(d,[(24,92),(72,92),(81,100),(17,100)],'#273842')
    r(d,(26,74,70,93), '#536672', OUT,3)
    brick(d,27,75,70,93,4)
    # Stone taper body.
    poly(d,[(34,37),(64,37),(73,79),(25,79)],'#82949a',OUT,3)
    poly(d,[(52,40),(64,40),(72,77),(52,77)],'#5c707f')
    brick(d,27,44,72,78,13)
    r(d,(44,58,54,74),'#2c3842','#a2a99c',2)
    if name == 'arrow':
        r(d,(20,34,76,43),'#394f45',OUT,3)
        for x in [20,31,44,56,68]:r(d,(x,26,x+9,37),'#91a993',OUT,2)
        poly(d,[(16,32),(48,8),(80,32)],'#4b785c',OUT,4)
        poly(d,[(48,9),(79,32),(52,32)],'#2e554b')
        for y in [17,23,29]:d.line((43,y,51,y),fill='#a4c6a0',width=2)
        r(d,(44,34,53,45),'#302f34','#efca7e',2)
        # Wooden firing platform and crossbow.
        r(d,(31,43,63,51),'#8e664d',OUT,2)
        d.line((28,39,67,39),fill='#ddb36b',width=4)
        d.line((35,35,35,45),fill='#fff1bd',width=2)
        d.line((61,35,61,45),fill='#fff1bd',width=2)
        r(d,(47,38,51,53),'#473d36')
    elif name == 'cannon':
        r(d,(19,36,77,46),'#6a5448',OUT,3)
        for x in [20,33,46,60,72]:r(d,(x,25,x+7,40),'#9c7460',OUT,2)
        r(d,(30,17,66,37),'#bd8b64',OUT,3)
        r(d,(34,12,62,21),'#d8af7c',OUT,3)
        r(d,(24,45,71,56),'#4b4749',OUT,2)
        # a barrel facing right, isometric metallic bands.
        poly(d,[(42,36),(74,27),(85,34),(82,45),(48,51)],'#34414d',OUT,3)
        poly(d,[(49,37),(75,31),(81,35),(50,43)],'#84949d')
        r(d,(76,30,88,43),'#33404a',OUT,3)
        r(d,(78,34,84,38),'#131e2a')
        r(d,(38,49,58,56),'#b18557',OUT,2)
    elif name == 'frost':
        r(d,(19,34,77,45),'#47798b',OUT,3)
        for x in [21,34,49,64]:r(d,(x,26,x+10,37),'#87b9c4',OUT,2)
        poly(d,[(24,38),(48,6),(72,38),(62,52),(33,52)],'#6fd6d7',OUT,4)
        poly(d,[(48,7),(71,38),(50,37)],'#3a97b0')
        poly(d,[(45,17),(40,35),(51,43),(53,20)],'#c6f9dd')
        r(d,(44,48,53,57),'#d4eff2',OUT,2)
        for x,y in [(22,18),(71,14),(78,60)]:
            d.line((x-4,y,x+4,y),fill='#c6fbeb',width=2);d.line((x,y-4,x,y+4),fill='#c6fbeb',width=2)
    elif name == 'flame':
        r(d,(20,34,76,44),'#774845',OUT,3)
        for x in [21,35,49,63]:r(d,(x,24,x+11,37),'#b16f57',OUT,2)
        poly(d,[(30,43),(27,28),(42,25),(35,13),(50,18),(55,7),(64,26),(73,34),(65,48),(48,50)],'#ee8a3f',OUT,3)
        poly(d,[(37,42),(40,28),(48,31),(54,17),(60,35),(56,44)],'#ffd16b')
        r(d,(40,48,55,60),'#806548',OUT,2)
        for x,y in [(24,13),(71,15),(78,48)]:r(d,(x,y,x+3,y+3),'#ffc373')
    save('tower_'+name,im)

def enemy(name):
    scale=1.2 if name=='brute' else 1.75 if name=='boss' else 1
    W=int(64*scale); H=int(72*scale);im=canvas((W,H));d=ImageDraw.Draw(im)
    def P(x,y):return (round(x*scale),round(y*scale))
    def R(x1,y1,x2,y2,c,outline=None,wd=2):r(d,(*P(x1,y1),*P(x2,y2)),c,outline,max(1,round(wd*scale)))
    def poly2(pts,c,outline=None,wd=2):poly(d,[P(*pt) for pt in pts],c,outline,max(1,round(wd*scale)))
    def line(x1,y1,x2,y2,c,w=2):d.line((*P(x1,y1),*P(x2,y2)),fill=c,width=max(1,round(w*scale)))
    d.ellipse((*P(14,60),*P(50,70)),fill=(11,18,19,105))
    if name=='grunt':
        R(17,47,28,62,'#43513d',OUT,2);R(36,47,47,62,'#43513d',OUT,2)
        poly2([(16,31),(48,31),(53,54),(10,54)],'#708e58',OUT,3)
        R(22,34,42,47,'#90a96b');R(26,45,37,55,'#b48a5c',OUT)
        R(13,37,18,52,'#6c8355',OUT);R(46,36,51,52,'#6c8355',OUT)
        poly2([(15,13),(23,7),(30,13),(41,8),(50,15),(48,35),(17,35)],'#85a964',OUT,3)
        poly2([(15,19),(9,13),(12,32),(18,31)],'#6c8c56',OUT,2)
        R(23,23,29,27,'#e8da8b');R(38,23,44,27,'#e8da8b');R(27,25,29,27,'#2b3036');R(39,25,41,27,'#2b3036')
        R(29,32,37,34,'#4c533d');R(22,9,43,11,'#c2c178')
    elif name=='runner':
        R(16,48,26,63,'#9a6346',OUT,2);R(39,49,48,59,'#9a6346',OUT,2)
        poly2([(19,33),(45,32),(53,48),(15,54)],'#d5a65f',OUT,3)
        poly2([(14,14),(24,9),(42,10),(51,17),(47,37),(16,37)],'#d4aa58',OUT,3)
        poly2([(15,15),(10,9),(13,31),(18,31)],'#b7823e',OUT)
        poly2([(46,16),(54,10),(52,31),(47,31)],'#b7823e',OUT)
        R(21,23,28,27,'#f8e6ab');R(37,23,44,27,'#f8e6ab')
        R(25,24,27,27,'#3b3232');R(39,24,41,27,'#3b3232');R(20,12,47,15,'#efdb85')
        line(10,42,5,54,'#e9d3a4',4);line(52,43,60,35,'#e9d3a4',4)
    elif name=='brute':
        R(17,48,29,63,'#454657',OUT,2);R(35,48,47,63,'#454657',OUT,2)
        poly2([(12,30),(51,28),(57,54),(7,54)],'#606278',OUT,3)
        R(21,37,42,49,'#857f86',OUT,2)
        R(7,37,14,51,'#626277',OUT);R(51,36,59,51,'#626277',OUT)
        poly2([(10,16),(22,11),(42,10),(53,18),(49,36),(15,37)],'#a08d8e',OUT,3)
        poly2([(14,13),(5,7),(15,25)],'#b4a1a0',OUT);poly2([(48,14),(58,7),(52,25)],'#b4a1a0',OUT)
        R(19,23,28,29,'#f5c989');R(38,23,47,29,'#f5c989');R(24,25,27,28,'#4e4543');R(40,25,43,28,'#4e4543')
        R(26,32,39,35,'#504952');R(15,38,49,42,'#d0b58d',OUT)
    elif name=='boss':
        R(14,49,29,63,'#4d354d',OUT,2);R(36,49,50,63,'#4d354d',OUT,2)
        poly2([(10,32),(51,32),(59,54),(5,54)],'#81476a',OUT,3)
        poly2([(8,31),(17,24),(32,28),(46,23),(57,31),(55,49),(8,49)],'#ac4e75',OUT,3)
        poly2([(12,15),(22,7),(32,13),(44,7),(54,16),(53,37),(10,38)],'#c15f86',OUT,3)
        poly2([(15,19),(5,0),(21,13)],'#de9ab7',OUT,2)
        poly2([(47,17),(59,0),(57,24)],'#de9ab7',OUT,2)
        poly2([(23,11),(32,0),(41,11)],'#f0bf81',OUT,2)
        R(19,23,28,29,'#ffe6a7');R(37,23,46,29,'#ffe6a7');R(23,25,27,28,'#6d1a42');R(39,25,43,28,'#6d1a42')
        R(25,33,41,36,'#512d43');R(13,42,53,46,'#e6a970',OUT)
    save('enemy_'+name,im)

def castle():
    im=canvas((256,264));d=ImageDraw.Draw(im)
    d.ellipse((27,218,232,254),fill=(10,19,23,105))
    # Base courtyard and outer walls; semi-topdown 3/4 isometry.
    poly(d,[(39,143),(215,143),(235,181),(215,234),(42,234),(20,185)],'#3b4c5c',OUT,5)
    poly(d,[(38,146),(214,146),(214,218),(38,218)],'#72848e',OUT,5)
    r(d,(43,149,211,218),'#8c9697')
    brick(d,44,153,209,217,24)
    # Side walls.
    poly(d,[(31,145),(58,137),(64,209),(40,226),(27,206)],'#647782',OUT,4)
    poly(d,[(201,140),(226,148),(230,207),(213,226),(198,215)],'#536774',OUT,4)
    # Main keep central behind parapets.
    r(d,(78,83,177,195),'#788d9a',OUT,5)
    r(d,(86,91,169,178),'#9aa8aa')
    brick(d,87,100,168,178,91)
    r(d,(116,142,141,193),'#344956',OUT,4)
    r(d,(121,151,136,191),'#1f2f3f')
    # Keep top roof slates.
    poly(d,[(67,86),(125,35),(184,86),(177,104),(80,104)],'#4f7790',OUT,5)
    poly(d,[(125,35),(185,85),(126,86)],'#385770')
    for y in [57,67,78,89]:
        xx=int((y-35)*.84)
        d.line((125-xx,y,125+xx,y),fill='#6f92a0',width=2)
    # Grand central banner.
    r(d,(123,90,128,143),'#e7d4a1')
    poly(d,[(116,99),(136,99),(136,137),(126,131),(116,137)],'#cc665f',OUT,2)
    r(d,(123,108,129,127),'#ffe3a2')
    # Wall front and crenellations.
    r(d,(31,185,223,221),'#6d7d8b',OUT,5)
    brick(d,34,187,221,219,44)
    for x in range(34,216,22):r(d,(x,175,x+15,190),'#9babaa',OUT,3)
    # Front gate has stepped arch.
    r(d,(109,185,145,224),'#273b49',OUT,4)
    r(d,(113,191,141,230),'#685143',OUT,3)
    for xx in [120,129,137]:d.line((xx,192,xx,227),fill='#493a38',width=2)
    r(d,(138,207,140,214),'#d3b777')
    # Corner towers: shadows, body, roof, battlements.
    for xx,yy,flip in [(31,75,False),(179,75,True),(20,146,False),(190,146,True)]:
        r(d,(xx+8,yy+26,xx+42,yy+112 if yy<120 else yy+81),'#5d7480',OUT,4)
        r(d,(xx+12,yy+33,xx+35,yy+88 if yy<120 else yy+69),'#91a2a5')
        for by in range(yy+43,yy+(102 if yy<120 else 72),10):
            d.line((xx+15,by,xx+35,by),fill='#6f858c',width=1)
        r(d,(xx+3,yy+17,xx+46,yy+35),'#80939a',OUT,4)
        for tx in [xx+3,xx+17,xx+31]:r(d,(tx,yy+6,tx+12,yy+24),'#bac2ae',OUT,2)
        r(d,(xx+23,yy+54,xx+29,yy+70),'#344553',OUT,2)
    # Windows, tiny torches
    for x in [89,160]:
        r(d,(x,131,x+7,144),'#273d4c',OUT,2)
    for x in [98,157]:
        r(d,(x,205,x+4,216),'#b67d4a',OUT)
        r(d,(x-2,201,x+6,207),'#f4ca74')
    # Flag atop keep, always consistently NW light.
    r(d,(125,9,128,39),'#e6d4a6')
    poly(d,[(129,12),(160,17),(130,28)],'#c96c64',OUT,2)
    r(d,(135,16,142,20),'#f0d897')
    save('castle',im)

def env(name):
    im=canvas((72,80));d=ImageDraw.Draw(im)
    d.ellipse((12,60,61,73),fill=(11,21,20,84))
    if name=='tree':
        r(d,(29,41,44,68),'#654c3c',OUT,3)
        r(d,(33,43,38,65),'#9b7050')
        for x,y,w,h,c in [(15,30,44,31,'#326756'),(10,23,53,29,'#2d715b'),(19,13,39,34,'#3b8263'),(27,4,24,23,'#5a9772')]:
            d.ellipse((x,y,x+w,y+h),fill=c,outline=OUT,width=3)
        for x,y in [(21,31),(32,18),(43,30),(29,40),(48,44)]:r(d,(x,y,x+7,y+4),'#7db489')
    if name=='rock':
        poly(d,[(12,62),(18,35),(37,24),(56,39),(65,61),(46,70),(23,69)],'#647783',OUT,3)
        poly(d,[(20,40),(37,28),(43,50),(19,61)],'#a4ada8')
        poly(d,[(44,38),(57,43),(62,59),(42,63)],'#485d6c')
        r(d,(23,52,33,55),'#c2beb1');r(d,(47,55,54,58),'#8298a0')
    if name=='crystal':
        poly(d,[(15,67),(11,40),(28,15),(37,27),(45,6),(60,30),(59,60),(44,73)],'#376c7b',OUT,3)
        poly(d,[(14,42),(28,17),(38,47),(33,70),(13,66)],'#69c7c7')
        poly(d,[(45,9),(57,31),(47,64),(38,47)],'#90e7d8')
        poly(d,[(22,44),(28,28),(31,51)],'#d7fff0')
    save(name,im)

if __name__=='__main__':
    for nm in ['arrow','cannon','frost','flame']:tower(nm)
    for nm in ['grunt','runner','brute','boss']:enemy(nm)
    castle()
    for nm in ['tree','rock','crystal']:env(nm)
    print('Generated',len(list(ROOT.glob('*.png'))),'pixel-art PNGs in',ROOT)
