from pathlib import Path
from PIL import Image
r=Path('/mnt/data/PIXEL_BASTION_v030_work')
js=(r/'game.js').read_text()
ht=(r/'index.html').read_text()
css=(r/'style.css').read_text()

def replace1(a,b):
 global js
 assert a in js,a[:160]
 js=js.replace(a,b,1)

# Crop only transparent margins from user's original house, without painting/resampling.
h=Image.open('/mnt/data/PIXEL_BASTION_하급_초가집_1번_투명배경(1).png').convert('RGBA')
h=h.crop(h.getbbox())
h.save(r/'assets/sprites/house_thatch.png',optimize=True)

replace1('PIXEL BASTION v0.2.0 — central castle / 8-direction open-field defense.', 'PIXEL BASTION v0.3.0 — defense + village residents; original user sprites.')
replace1("    zoomIn: document.getElementById('zoomInBtn'), zoomOut: document.getElementById('zoomOutBtn')", "    zoomIn: document.getElementById('zoomInBtn'), zoomOut: document.getElementById('zoomOutBtn'),\n    pop: document.getElementById('populationValue'), capacity: document.getElementById('populationCapValue'),\n    houseCount: document.getElementById('houseCountValue'), houseButton: document.getElementById('houseBuildBtn'),\n    houseSub: document.getElementById('houseSubText')")
replace1("  const DIRS = ['북쪽'", "  const HOUSE_LIMIT = 3;\n  const HOUSE_SIZE = 3;\n  const HOUSE_CAPACITY = 3;\n  // Provisional visualization timing; final immigration system is not designed yet.\n  const ARRIVAL_SECONDS = 12;\n  const NPC_POSES = ['surprised','happy','thinking','greeting_wave','greeting_bow','talking_01','talking_02'];\n  const npcImages = {};\n  function loadNpcImages() {\n    const urls={walk:'assets/npc/NPC_MALE/male_walk_4dir_3frames.png',emotes:'assets/npc/NPC_MALE/male_emotes_7poses.png',idle:'assets/npc/NPC_MALE/aligned_idle_down.png'};\n    Object.entries(urls).forEach(([name,url])=>{const img=new Image();img.onload=()=>{npcImages[name]=img;};img.src=url;});\n  }\n  const DIRS = ['북쪽'")
replace1('let lastFrame = 0, enemySerial = 0, towerSerial = 0, uiTimer = 0, toastTimeout = 0;', 'let lastFrame = 0, enemySerial = 0, towerSerial = 0, houseSerial = 0, villagerSerial = 0, uiTimer = 0, toastTimeout = 0;')
replace1("      selection:null,build:null,hover:null,castleFlash:0,threatDirections:[],elapsed:0,killBonus:0", "      selection:null,build:null,hover:null,castleFlash:0,threatDirections:[],elapsed:0,killBonus:0,\n      houses:[],villagers:[],immigrationClock:0")
replace1('    enemySerial=0;towerSerial=0;', '''    enemySerial=0;towerSerial=0;houseSerial=0;villagerSerial=0;
    // Demonstration settlement: one existing hut with one resident. New huts begin empty.
    const starter=findStarterHouse();
    if(starter){const home=createHouse(starter.tx,starter.ty);spawnVillager(home,true);}''')
replace1("    ui.tip.textContent='성 주변 8방향을 방어하세요. 적은 길에만 묶이지 않습니다.';", "    ui.tip.textContent='초가집은 최대 3채 · 집 1채당 주민 최대 3명. 주민을 클릭해 모션을 확인하세요.';")
replace1("    if(state.build)toast(TOWERS[state.build].label+' 배치: 원하는 지면을 클릭');", "    if(state.build)toast(state.build==='house'?'초가집 배치: 3×3 빈 지면을 클릭':TOWERS[state.build].label+' 배치: 원하는 지면을 클릭');")
replace1('    for(const tower of state.towers){if(distance(x,y,tower.x,tower.y)<56)return \'다른 타워와 너무 가깝습니다.\';}', '''    for(const tower of state.towers){if(distance(x,y,tower.x,tower.y)<56)return '다른 타워와 너무 가깝습니다.';}
    for(const home of state.houses){if(Math.abs(x-home.x)<90 && Math.abs(y-home.y)<90)return '초가집이 있는 땅에는 타워를 세울 수 없습니다.';}''')
anchor='  function towerStats(t){'
assert anchor in js
code='''  // Houses reserve exactly 3×3 world tiles, even though their roof protrudes visually.
  function snapHouse(wx,wy){
    const tx=Math.floor(wx/TILE)-1,ty=Math.floor(wy/TILE)-1;
    return{tx,ty,x:(tx+HOUSE_SIZE/2)*TILE,y:(ty+HOUSE_SIZE/2)*TILE};
  }
  function canPlaceHouse(tx,ty){
    if(state.houses.length>=HOUSE_LIMIT)return '초가집은 최대 3채까지 건설할 수 있습니다.';
    if(tx<2||ty<2||tx+HOUSE_SIZE>=MAP-2||ty+HOUSE_SIZE>=MAP-2)return '월드 밖에는 건설할 수 없습니다.';
    const px=(tx+1.5)*TILE,py=(ty+1.5)*TILE;
    if(distance(px,py,C,C)<245)return '중앙 성과 너무 가깝습니다.';
    if(distance(px,py,C,C)>940)return '마을 건설 권역 밖입니다.';
    for(let j=0;j<3;j++)for(let i=0;i<3;i++){
      const cell=tiles[key(tx+i,ty+j)];
      if(cell.obstacle||cell.terrain===6||cell.terrain===5)return '길, 물, 장애물이 없는 3×3 공간이 필요합니다.';
    }
    for(const t of state.towers){if(Math.abs(px-t.x)<82&&Math.abs(py-t.y)<82)return '기존 타워와 겹칩니다.';}
    for(const h of state.houses){if(Math.abs(px-h.x)<120&&Math.abs(py-h.y)<120)return '다른 집과 겹칩니다.';}
    return '';
  }
  function createHouse(tx,ty){
    const home={id:++houseSerial,type:'house',tx,ty,x:(tx+1.5)*TILE,y:(ty+1.5)*TILE,level:1};
    state.houses.push(home);return home;
  }
  function findStarterHouse(){
    const sites=[[-310,175],[320,135],[-310,-155],[335,-175],[-390,210],[390,210]];
    for(const [dx,dy] of sites){const s=snapHouse(C+dx,C+dy);if(!canPlaceHouse(s.tx,s.ty))return s;}
    for(let ty=30;ty<=52;ty++)for(let tx=30;tx<=52;tx++){
      if(!canPlaceHouse(tx,ty))return{tx,ty};
    }
    return null;
  }
  function buildHouse(wx,wy){
    const p=snapHouse(wx,wy),err=canPlaceHouse(p.tx,p.ty);
    if(err){toast(err);return false;}
    const h=createHouse(p.tx,p.ty);
    // Construction cost is intentionally not set until the user determines gold rules.
    state.selection=h;state.build=null;
    spawnParticles(h.x,h.y+36,'#f8d78c',16);
    toast('초가집 건설 완료 · 주민이 점차 입주합니다.');
    updateUI();updateInspector();return true;
  }
  function homePopulation(home){return state.villagers.filter(v=>v.homeId===home.id).length;}
  function spawnVillager(home,starting=false){
    if(!home || homePopulation(home)>=HOUSE_CAPACITY)return null;
    const v={id:++villagerSerial,type:'villager',homeId:home.id,x:home.x+rand(-16,16),y:home.y+92,
      dir:'down',mode:'idle',walkTime:0,action:'',actionTime:0,idleTime:starting?2:rand(1,3),
      target:null,speed:rand(35,46),bubble:'',bubbleTime:0};
    state.villagers.push(v);
    if(!starting){spawnParticles(v.x,v.y-20,'#cfedb6',9);floating(v.x,v.y-70,'새 주민 +1','#e9f4b0');}
    return v;
  }
  function selectHouseBuild(){
    if(state.gameOver)return;
    if(state.houses.length>=HOUSE_LIMIT){toast('초가집은 이미 3채입니다.');return;}
    selectBuild('house');
  }
  function triggerNpcPose(v,pose){
    if(!v||!NPC_POSES.includes(pose))return;
    v.mode='emote';v.action=pose;v.actionTime=pose.startsWith('talking')?3.2:2.1;
    v.target=null;v.bubbleTime=1.55;
    v.bubble=({surprised:'!',happy:'♪',thinking:'…',greeting_wave:'안녕!',greeting_bow:'꾸벅!',talking_01:'안녕하세요!',talking_02:'반가워요!'})[pose]||'';
    updateInspector();
  }
  function npcPassable(x,y){
    if(x<15||y<15||x>WORLD-15||y>WORLD-15)return false;
    const t=tileAt(x,y);
    if(t.terrain===6||t.obstacle)return false;
    if(Math.abs(x-C)<137&&Math.abs(y-C)<118)return false;
    for(const h of state.houses){if(Math.abs(x-h.x)<63&&Math.abs(y-h.y)<65)return false;}
    for(const t of state.towers){if(distance(x,y,t.x,t.y)<28)return false;}
    return true;
  }
  function pickNpcTarget(v){
    const h=state.houses.find(h=>h.id===v.homeId);
    if(!h)return null;
    for(let attempt=0;attempt<28;attempt++){
      const a=rand(0,Math.PI*2),r=rand(95,245);
      const dest={x:h.x+Math.cos(a)*r,y:h.y+Math.sin(a)*r};
      if(!npcPassable(dest.x,dest.y))continue;
      let clear=true;
      for(let i=1;i<=12;i++){
        const f=i/12;if(!npcPassable(v.x+(dest.x-v.x)*f,v.y+(dest.y-v.y)*f)){clear=false;break;}
      }
      if(clear)return dest;
    }
    return null;
  }
  function stepVillagers(dt){
    if(!state.houses.length)return;
    state.immigrationClock+=dt;
    if(state.immigrationClock>=ARRIVAL_SECONDS){
      state.immigrationClock-=ARRIVAL_SECONDS;
      const available=state.houses.filter(h=>homePopulation(h)<HOUSE_CAPACITY);
      if(available.length){
        const h=available.reduce((best,h)=>homePopulation(h)<homePopulation(best)?h:best,available[0]);
        spawnVillager(h);
        if(state.selection===h)updateInspector();
      }
    }
    for(const v of state.villagers){
      v.bubbleTime=Math.max(0,v.bubbleTime-dt);
      if(v.actionTime>0){
        v.actionTime-=dt;
        if(v.actionTime<=0){v.action='';v.mode='idle';v.idleTime=rand(.6,2.3);}
        continue;
      }
      if(v.target){
        const d=distance(v.x,v.y,v.target.x,v.target.y);
        if(d<3){v.target=null;v.mode='idle';v.idleTime=rand(1.0,3.0);continue;}
        const dx=(v.target.x-v.x)/d,dy=(v.target.y-v.y)/d;
        v.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up');
        const step=Math.min(d,v.speed*dt);
        if(npcPassable(v.x+dx*step,v.y+dy*step)){
          v.x+=dx*step;v.y+=dy*step;v.walkTime+=dt;
        }else{v.target=null;v.mode='idle';v.idleTime=1.0;}
      }else{
        v.idleTime-=dt;
        if(v.idleTime<=0){
          // Residents occasionally emote and talk, without creating resource effects.
          if(Math.random()<.23){triggerNpcPose(v,NPC_POSES[Math.floor(Math.random()*NPC_POSES.length)]);}
          else {v.target=pickNpcTarget(v);v.mode=v.target?'walk':'idle';v.idleTime=rand(1,2);}
        }
      }
    }
  }
  function drawHouse(h){
    const w=136,hh=164;
    drawSprite('house_thatch',h.x-w/2,h.y-hh+38,w,hh);
    if(state.selection===h){
      ctx.lineWidth=2;ctx.strokeStyle='#f9db95';ctx.strokeRect(h.tx*TILE,h.ty*TILE,120,120);
      ctx.fillStyle='#1b302bdc';ctx.fillRect(h.x-43,h.y-124,86,19);
      ctx.textAlign='center';ctx.font='bold 12px Consolas,monospace';ctx.fillStyle='#f5e8bd';
      ctx.fillText('주민 '+homePopulation(h)+'/3',h.x,h.y-111);
    }
  }
  function drawNpc(v){
    const s=.37,walkScale=.41,dirIndex={down:0,up:1,left:2,right:3};
    ctx.fillStyle='#18272277';ctx.beginPath();ctx.ellipse(v.x,v.y-2,16,5,0,0,Math.PI*2);ctx.fill();
    if(v.action && npcImages.emotes){
      const pose=v.action.startsWith('talking')?(Math.floor(state.elapsed*3.9)%2?'talking_01':'talking_02'):v.action;
      const col=NPC_POSES.indexOf(pose);
      const w=200*s,h=220*s;
      ctx.drawImage(npcImages.emotes,col*200,0,200,220,Math.round(v.x-w/2),Math.round(v.y-h),w,h);
    }else if(v.target&&npcImages.walk){
      const w=160*walkScale,h=168*walkScale;
      const row=dirIndex[v.dir],col=Math.floor(v.walkTime*7)%3;
      ctx.drawImage(npcImages.walk,col*160,row*168,160,168,Math.round(v.x-w/2),Math.round(v.y-h),w,h);
    }else if(npcImages.idle){
      const w=160*.35,h=208*.35;
      ctx.drawImage(npcImages.idle,Math.round(v.x-w/2),Math.round(v.y-h),w,h);
    }else {ctx.fillStyle='#d8a474';ctx.fillRect(v.x-9,v.y-32,18,30);}
    if(v.bubbleTime>0&&v.bubble){
      ctx.font='bold 12px sans-serif';const width=Math.min(110,Math.max(27,ctx.measureText(v.bubble).width+15));
      ctx.fillStyle='#18272ee6';ctx.fillRect(v.x-width/2,v.y-100,width,23);
      ctx.strokeStyle='#f9db9a';ctx.lineWidth=1;ctx.strokeRect(v.x-width/2,v.y-100,width,23);
      ctx.fillStyle='#fff2dc';ctx.textAlign='center';ctx.fillText(v.bubble,v.x,v.y-84);
    }
    if(state.selection===v){ctx.strokeStyle='#ffe3a0';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(v.x,v.y-3,24,10,0,0,Math.PI*2);ctx.stroke();}
  }
'''
js=js.replace(anchor,code+anchor,1)
# Upgrade inspector for three object types.
replace1("    const def=TOWERS[t.type],stats=towerStats(t),max=t.level===3;", """    if(t.type==='house'){
      ui.inspector.innerHTML=`<div class="inspector-title"><strong>하급 초가집</strong><span class="level">주거 건물</span></div>
      <div class="inspector-stats"><div><span>건설 면적</span><strong>3 × 3칸</strong></div><div><span>입주 인원</span><strong>${homePopulation(t)} / 3명</strong></div>
      <div><span>초가집 개수</span><strong>${state.houses.length} / 3채</strong></div><div><span>진화 시스템</span><strong>준비 중</strong></div></div>
      <div class="inspector-actions"><button type="button" class="btn btn-primary" disabled title="진화 조건 미확정">🔒 진화 잠금</button></div>`;
      return;
    }
    if(t.type==='villager'){
      ui.inspector.innerHTML=`<div class="inspector-title"><strong>남성 주민 #${t.id}</strong><span class="level">마을 주민</span></div>
      <p class="npc-hint">주민을 선택한 상태에서 아래 모션을 눌러 보세요. 감정은 경제 수치에 영향을 주지 않습니다.</p>
      <div class="npc-actions"><button type="button" data-pose="greeting_wave">👋 손인사</button><button type="button" data-pose="greeting_bow">🙇 숙여인사</button><button type="button" data-pose="happy">😊 기쁨</button><button type="button" data-pose="surprised">❗ 놀람</button><button type="button" data-pose="thinking">💭 생각</button><button type="button" data-pose="talking_01">💬 대화</button></div>`;
      return;
    }
    const def=TOWERS[t.type],stats=towerStats(t),max=t.level===3;""")
replace1('    ui.gold.textContent=Math.floor(state.gold);ui.lives.textContent=Math.max(0,Math.ceil(state.lives));', '''    ui.gold.textContent=Math.floor(state.gold);ui.lives.textContent=Math.max(0,Math.ceil(state.lives));
    ui.pop.textContent=state.villagers.length;ui.capacity.textContent=state.houses.length*HOUSE_CAPACITY;
    ui.houseCount.textContent=state.houses.length+'/'+HOUSE_LIMIT;
    ui.houseButton.disabled=state.houses.length>=HOUSE_LIMIT||state.gameOver;
    ui.houseButton.setAttribute('aria-pressed',String(state.build==='house'));
    ui.houseSub.textContent=state.houses.length>=HOUSE_LIMIT?'3/3 건설 제한 도달':'최대 3채 · 3×3칸 · 비용 미정';''')
replace1("'방어 준비 · 타워 '+state.towers.length+'개'", "'방어 준비 · 타워 '+state.towers.length+'개 · 주민 '+state.villagers.length+'명'")
replace1('    stepTowers(dt);stepShots(dt);', '    stepTowers(dt);stepShots(dt);')
replace1('      stepParticles(dt);', '      stepParticles(dt);\n      stepVillagers(dt);')
replace1("    for(const t of state.towers)if(t.x>b.left-90", "    for(const h of state.houses)if(h.x>b.left-120&&h.x<b.right+120&&h.y>b.top-180&&h.y<b.bottom+140)all.push({y:h.y+48,kind:'house',obj:h});\n    for(const v of state.villagers)if(v.x>b.left-100&&v.x<b.right+100&&v.y>b.top-120&&v.y<b.bottom+100)all.push({y:v.y,kind:'npc',obj:v});\n    for(const t of state.towers)if(t.x>b.left-90")
replace1("      }else if(entry.kind==='tower')drawTower(entry.obj);", "      }else if(entry.kind==='house')drawHouse(entry.obj);\n      else if(entry.kind==='npc')drawNpc(entry.obj);\n      else if(entry.kind==='tower')drawTower(entry.obj);")
replace1("    const range=TOWERS[state.build].range,valid=canBuild(p.x,p.y)===''&&state.gold>=TOWERS[state.build].cost;", """    if(state.build==='house'){
      const h=snapHouse(state.hover.x,state.hover.y);
      const valid=canPlaceHouse(h.tx,h.ty)==='';
      ctx.fillStyle=valid?'rgba(179,242,179,.2)':'rgba(253,100,96,.24)';
      ctx.fillRect(h.tx*TILE,h.ty*TILE,120,120);
      ctx.strokeStyle=valid?'#e6eaba':'#f59c87';ctx.lineWidth=3;
      ctx.strokeRect(h.tx*TILE,h.ty*TILE,120,120);
      ctx.globalAlpha=.7;drawSprite('house_thatch',h.x-68,h.y-126,136,164);ctx.globalAlpha=1;
      return;
    }
    const range=TOWERS[state.build].range,valid=canBuild(p.x,p.y)===''&&state.gold>=TOWERS[state.build].cost;""")
replace1("    for(const t of state.towers){miniCtx.fillStyle='#fff2c7';miniCtx.fillRect(t.x*sc-1,t.y*sc-1,3,3);}", "    for(const t of state.towers){miniCtx.fillStyle='#fff2c7';miniCtx.fillRect(t.x*sc-1,t.y*sc-1,3,3);}\n    for(const h of state.houses){miniCtx.fillStyle='#efb36d';miniCtx.fillRect(h.x*sc-2,h.y*sc-2,5,5);}\n    for(const v of state.villagers){miniCtx.fillStyle='#d0fcdb';miniCtx.fillRect(v.x*sc,v.y*sc,2,2);}")
replace1("    if(state.build){placeTower(state.build,w.x,w.y);return;}\n    state.selection=nearest;updateInspector();", """    if(state.build){if(state.build==='house')buildHouse(w.x,w.y);else placeTower(state.build,w.x,w.y);return;}
    // Prefer the resident when multiple sprites overlap under the cursor.
    for(const v of state.villagers){
      if(Math.abs(w.x-v.x)<27&&w.y<v.y+10&&w.y>v.y-72){
        state.selection=v;triggerNpcPose(v,'greeting_wave');updateInspector();return;
      }
    }
    if(!nearest){for(const h of state.houses){
      if(Math.abs(w.x-h.x)<72&&w.y>h.y-126&&w.y<h.y+48){nearest=h;break;}
    }}
    state.selection=nearest;updateInspector();""")
replace1('  ui.towerList.addEventListener', "  ui.houseButton.addEventListener('click',selectHouseBuild);\n  ui.towerList.addEventListener")
replace1("    if(!button)return;\n    if(button.dataset.action==='upgrade')upgradeTower();", "    const pose=ev.target.closest('[data-pose]');\n    if(pose&&state.selection&&state.selection.type==='villager'){triggerNpcPose(state.selection,pose.dataset.pose);return;}\n    if(!button)return;\n    if(button.dataset.action==='upgrade')upgradeTower();")
replace1("    else if(k==='escape'){", "    else if(k==='5')selectHouseBuild();\n    else if(k==='escape'){")
replace1("      active:state.active,paused:state.paused,gameOver:state.gameOver,camera:{...camera}})", "      active:state.active,paused:state.paused,gameOver:state.gameOver,camera:{...camera},\n      houseCount:state.houses.length,population:state.villagers.length,populationCapacity:state.houses.length*HOUSE_CAPACITY,\n      houses:state.houses.map(h=>({id:h.id,x:h.x,y:h.y,tx:h.tx,ty:h.ty,residents:homePopulation(h)})),\n      villagers:state.villagers.map(v=>({id:v.id,x:v.x,y:v.y,dir:v.dir,action:v.action,homeId:v.homeId}))})")
replace1("    startWave:()=>startWave(),reset:()=>reset(),", "    startWave:()=>startWave(),reset:()=>reset(),\n    buildHouse:(x,y)=>buildHouse(x,y),\n    poseVillager:(id,pose)=>{const v=state.villagers.find(v=>v.id===id);if(!v)return false;triggerNpcPose(v,pose);return true;},")
replace1('  generateWorld();loadSprites();reset();', "  generateWorld();loadSprites();loadNpcImages();reset();")

# Change the asset image binding only (the original supplied art is kept pixel-identical inside bounding box).
cfg=(r/'assets/config.js').read_text()
print('CONFIG',cfg[-400:])
cfg=cfg.replace('  castle:', "  house_thatch: 'assets/sprites/house_thatch.png',\n  castle:") if '  castle:' in cfg else cfg
if 'house_thatch' not in cfg: # alternative fallback
 cfg=cfg.replace('window.PIXEL_ASSETS = {',"window.PIXEL_ASSETS = {\n  house_thatch: 'assets/sprites/house_thatch.png',")
(r/'assets/config.js').write_text(cfg)

# DOM amendments
ht=ht.replace('v0.2.0','v0.3.0').replace('OPEN FIELD DEFENSE','DEFENSE × VILLAGE')
needle='    <main class="game-layout">'
assert needle in ht
ht=ht.replace(needle,'''    <section class="settlement-strip" aria-label="마을 경영 지표">
      <div class="settlement-meter"><b>👥 인구</b><strong><span id="populationValue">1</span> / <span id="populationCapValue">3</span></strong><small>집 1채당 최대 3명</small></div>
      <div class="settlement-meter"><b>🏠 초가집</b><strong id="houseCountValue">1/3</strong><small>3×3칸 · 진화 잠금</small></div>
      <div class="settlement-meter provisional"><b>🌾 식량</b><strong>미설정</strong><small>규칙 확정 대기</small></div>
      <div class="settlement-meter provisional"><b>♥ 민심</b><strong>미설정</strong><small>규칙 확정 대기</small></div>
    </section>

'''+needle,1)
ht=ht.replace('중앙 성을 지켜라</div>','마을과 성을 지켜라</div>')
ht=ht.replace('사방에서 적이 몰려옵니다. 타워를 배치하고 웨이브를 시작하세요.','사방을 방어하고 초가집을 지어 주민을 늘려 보세요.')
ht=ht.replace('숫자키: 타워 / 드래그: 이동 / ESC: 취소', '1~4: 타워 / 5: 초가집 / 주민 클릭: 감정 / ESC: 취소')
ht=ht.replace('성 주변 8방향을 방어하세요. 적은 길에만 묶이지 않습니다.','초가집 최대 3채, 주민 최대 9명 · 주민 클릭으로 상호작용')
needle='      <aside class="sidebar">\n'
assert needle in ht
ht=ht.replace(needle,needle+'''        <div class="panel-heading"><div><span class="tiny-rect amber"></span><b>마을 경영</b></div><span class="shortcut">단축키 5</span></div>
        <div class="settlement-build" id="settlementBuild">
          <button type="button" id="houseBuildBtn" class="house-build" aria-pressed="false"><img src="assets/sprites/house_thatch.png" alt="하급 초가집 도트 이미지"><span><strong>하급 초가집</strong><em>인구 최대 +3 · 3×3칸</em><small id="houseSubText">최대 3채 · 비용 미정</small></span></button>
          <p>주민은 시간이 지나며 자동 입주합니다. 주민을 클릭하면 감정·대화 모션을 볼 수 있습니다.</p>
        </div>
''',1)
ht=ht.replace('선택한 타워</div>', '선택한 건물 / 주민</div>')
ht=ht.replace('타워를 건설하거나 기존 타워를 클릭하세요.', '타워 · 초가집 · 주민을 클릭하세요.')
ht=ht.replace('모든 리소스는 <code>assets/sprites</code>의 고해상도 도트 PNG로 교체 가능합니다.', '남성 주민 모션은 <code>assets/npc/NPC_MALE</code>의 사용자 제공 원본 시트를 사용합니다.')
(r/'index.html').write_text(ht)
css+='''
/* PIXEL BASTION v0.3 — village management and resident interaction */
.settlement-strip{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:-3px 0 17px}
.settlement-meter{background:#1c3038;border:2px solid #3d5a56;box-shadow:2px 3px #102025;padding:10px 13px;display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.settlement-meter b{font-size:12px;color:#e8d6a9;white-space:nowrap}
.settlement-meter strong{font:900 17px Consolas,monospace;color:#e7f1cf}
.settlement-meter small{color:#91aaa2;font-size:10px;white-space:nowrap}
.settlement-meter.provisional{border-style:dashed}
.settlement-meter.provisional strong{font-size:12px;color:#adbac2}
.settlement-build{padding:12px 15px 15px;background:#1b3037;border-bottom:2px solid #30474b}
.settlement-build p{font-size:11px;color:#a5bab0;line-height:1.65;margin:10px 0 0}
.house-build{display:flex;width:100%;align-items:center;gap:13px;text-align:left;background:#294139;color:#f8edd7;border:2px solid #6a815b;cursor:pointer;padding:8px 10px;min-width:0}
.house-build:hover{background:#3e5541;border-color:#f0d292}
.house-build[aria-pressed=true]{background:#544f37;border-color:#f3d28e}
.house-build:disabled{opacity:.55;cursor:not-allowed}
.house-build img{width:65px;height:70px;object-fit:contain;image-rendering:pixelated;flex:none}
.house-build span{display:flex;flex-direction:column;gap:4px;min-width:0}
.house-build strong{font-size:14px}.house-build em{font-style:normal;font-size:11px;color:#c6d7b2}.house-build small{font-size:10px;color:#e9c78d}
.npc-hint{font-size:11px;line-height:1.6;margin:3px 0 11px;color:#b4c3bb}
.npc-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}
.npc-actions button{background:#304b4d;border:1px solid #63827d;color:#f0ead4;padding:9px 4px;font-size:12px;font-weight:800;cursor:pointer}
.npc-actions button:hover{background:#466864;border-color:#efce8a}
@media(max-width:960px){.settlement-strip{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:570px){.settlement-strip{gap:6px}.settlement-meter{padding:7px;gap:5px}.settlement-meter strong{font-size:14px}.settlement-meter b{font-size:10px}.settlement-meter small{font-size:9px}}
'''
(r/'style.css').write_text(css)
(r/'game.js').write_text(js)
print('Written game.js',len(js),'house',h.size)
