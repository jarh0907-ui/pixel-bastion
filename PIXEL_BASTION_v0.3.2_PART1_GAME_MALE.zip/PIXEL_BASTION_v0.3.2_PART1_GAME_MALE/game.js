(() => {
  'use strict';
  // PIXEL BASTION v0.3.2 — male/female residents, synchronized sprite scale and pacing.
  // No external libraries, server, API keys or third-party imagery.
  const TILE = 40;
  const MAP = 84;
  const WORLD = TILE * MAP;
  const C = WORLD / 2;
  const CW = 960, CH = 576;
  const MINZOOM = 0.56, MAXZOOM = 1.65;
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  const miniCanvas = document.getElementById('minimap');
  const miniCtx = miniCanvas.getContext('2d', { alpha: false });
  ctx.imageSmoothingEnabled = false;
  miniCtx.imageSmoothingEnabled = false;

  const ui = {
    gold: document.getElementById('goldValue'), lives: document.getElementById('livesValue'),
    wave: document.getElementById('waveValue'), kills: document.getElementById('killsValue'),
    waveBtn: document.getElementById('waveBtn'), pauseBtn: document.getElementById('pauseBtn'),
    speedBtn: document.getElementById('speedBtn'), restartBtn: document.getElementById('restartBtn'),
    banner: document.getElementById('canvasBanner'), inspector: document.getElementById('inspector'),
    towerList: document.getElementById('towerList'), tip: document.getElementById('tipText'),
    status: document.getElementById('statusText'), toast: document.getElementById('toast'),
    liveDot: document.getElementById('liveDot'), confirm: document.getElementById('confirmDialog'),
    threat: document.getElementById('threatBanner'), threatText: document.getElementById('threatText'),
    zoom: document.getElementById('zoomValue'), home: document.getElementById('homeMapBtn'),
    zoomIn: document.getElementById('zoomInBtn'), zoomOut: document.getElementById('zoomOutBtn'),
    pop: document.getElementById('populationValue'), capacity: document.getElementById('populationCapValue'),
    houseCount: document.getElementById('houseCountValue'), houseButton: document.getElementById('houseBuildBtn'),
    houseSub: document.getElementById('houseSubText')
  };

  const TOWERS = {
    arrow: {label:'궁수 탑', cost:80, damage:25, range:182, cooldown:.48, shotSpeed:600, color:'#f9d58e', description:'긴 사거리 / 단일 사격'},
    cannon:{label:'대포 탑', cost:135,damage:61, range:166, cooldown:1.44,shotSpeed:365,splash:58,color:'#ffbd83',description:'광역 폭발'},
    frost: {label:'빙결 탑', cost:115,damage:12, range:165, cooldown:.68,shotSpeed:490,slow:2.2,color:'#a0f2ef',description:'느려지는 적'},
    flame: {label:'화염 탑', cost:150,damage:29, range:136, cooldown:.59,shotSpeed:480,splash:42,burn:3.4,color:'#ffc06a',description:'폭발 + 지속 화상'}
  };
  const FOES = {
    grunt: {hp:100,speed:64,bounty:13,leak:12,size:24},
    runner:{hp:70, speed:99,bounty:14,leak:12,size:23},
    brute: {hp:280,speed:43,bounty:32,leak:25,size:29},
    boss:  {hp:1600,speed:37,bounty:160,leak:70,size:42}
  };
  const HOUSE_LIMIT = 3;
  const HOUSE_SIZE = 3;
  const HOUSE_CAPACITY = 3;
  // Provisional visualization timing; final immigration system is not designed yet.
  const ARRIVAL_SECONDS = 12;
  // One common world-space size and animation clock for male/female citizens.
  // All input PNGs are preserved byte-for-byte; per-frame alpha crops remove padding.
  const NPC_POSES = ['surprised','happy','thinking','greeting_wave','greeting_bow','talking_01','talking_02'];
  const NPC_EMOTE_POSES = ['surprised','happy','thinking','greeting_wave','greeting_bow'];
  const NPC_WALK_FPS = 3.8; // 0.263 s per frame for both genders; no 7-FPS animations.
  const NPC_TALK_FPS = 2.2; // Gentle two-pose conversational animation.
  const NPC_DRAW_HEIGHT = 60; // Same on-screen height in walk, idle, and emotes.
  const CHAT_MIN_SECONDS = 5, CHAT_MAX_SECONDS = 10;
  const NPC_DIRECTIONS = [{dx:0,dy:-1,dir:'up'}, {dx:1,dy:0,dir:'right'},
    {dx:0,dy:1,dir:'down'}, {dx:-1,dy:0,dir:'left'}];
  // Metadata from native alpha bounds in the user-provided transparent PNG sheets.
  // Female: 4 frames/direction + 6 emotes; male: 3 frames/direction + 7 emotes.
  const NPC_SPECS = {"male":{"walk":{"url":"assets/npc/NPC_MALE/male_walk_4dir_3frames.png","frameW":160,"frameH":168,"frames":3,"bounds":[[[32,22,128,162],[32,22,128,162],[32,22,127,162]],[[36,36,124,160],[36,36,124,160],[35,36,125,160]],[[35,31,125,160],[35,31,124,160],[35,28,125,162]],[[35,26,125,160],[35,26,124,160],[35,26,125,160]]]},"emotes":{"url":"assets/npc/NPC_MALE/male_emotes_7poses.png","frameW":200,"frameH":220,"poses":["surprised","happy","thinking","greeting_wave","greeting_bow","talking_01","talking_02"],"bounds":[[21,15,179,212],[20,23,179,212],[15,12,185,212],[31,22,169,212],[35,45,163,212],[31,14,170,212],[39,24,162,212]]},"idle":{"url":"assets/npc/NPC_MALE/aligned_idle_down.png","frameW":160,"frameH":208,"bounds":[24,14,135,200]}},"female":{"walk":{"url":"assets/npc/NPC_FEMALE/female_walk_4dir_4frames.png","frameW":160,"frameH":168,"frames":4,"bounds":[[[30,10,130,164],[31,9,131,164],[31,12,131,164],[29,9,130,164]],[[31,9,128,164],[31,9,128,164],[32,12,128,162],[32,9,128,164]],[[33,10,126,164],[33,11,126,164],[33,10,126,164],[33,9,127,164]],[[32,19,127,164],[32,19,128,164],[33,20,127,164],[33,20,127,164]]]},"emotes":{"url":"assets/npc/NPC_FEMALE/female_emotes_6poses.png","frameW":208,"frameH":224,"poses":["surprised","happy","thinking","greeting_wave","talking_01","talking_02"],"bounds":[[26,33,182,220],[16,34,192,220],[23,28,185,220],[27,34,180,220],[24,30,184,220],[30,36,177,220]]},"idle":{"url":"assets/npc/NPC_FEMALE/aligned_idle_down.png","frameW":160,"frameH":168,"bounds":[30,10,130,164]}}};
  const npcImages = {male:{},female:{}};
  function loadNpcImages() {
    for(const [gender,spec] of Object.entries(NPC_SPECS)) {
      for(const [type,descriptor] of Object.entries(spec)) {
        const img = new Image();
        img.onload=()=>{npcImages[gender][type]=img;};
        img.src=descriptor.url;
      }
    }
  }
  const DIRS = ['북쪽','북동','동쪽','남동','남쪽','남서','서쪽','북서'];
  const camera = {x:C,y:C,zoom:.94};
  const state = {};
  const sprites = {};
  const tiles = [];
  const tileCache = [];
  const decorations = [];
  const pressed = new Set();
  let lastFrame = 0, enemySerial = 0, towerSerial = 0, houseSerial = 0, villagerSerial = 0, uiTimer = 0, toastTimeout = 0;
  let miniBackground = null;
  let pointer = {active:false,id:null,x:0,y:0,lastX:0,lastY:0,drag:false,button:0};

  // Fast deterministic coordinate hash. World scenery doesn't change on reload.
  function hash(x,y,seed=0) {
    let h = (Math.imul(x+19, 374761393) + Math.imul(y+41, 668265263) + Math.imul(seed+7, 1274126177))|0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }
  const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
  const distance=(a,b,x,y)=>Math.hypot(a-x,b-y);
  const rand=(a,b)=>a+Math.random()*(b-a);
  const key=(cx,cy)=>cy*MAP+cx;
  const tileAt=(x,y)=>tiles[key(clamp(Math.floor(x/TILE),0,MAP-1),clamp(Math.floor(y/TILE),0,MAP-1))];

  function generateWorld() {
    const waterSpots = [{x:C-770,y:C+800,r:134},{x:C+890,y:C+590,r:104},{x:C-990,y:C-670,r:116}];
    for(let ty=0;ty<MAP;ty++) for(let tx=0;tx<MAP;tx++) {
      const x=tx*TILE+TILE/2, y=ty*TILE+TILE/2;
      const dx=x-C,dy=y-C,d=Math.hypot(dx,dy);
      const ang=Math.atan2(dy,dx);
      let roadDist=Infinity;
      for(let j=0;j<8;j++) {
        const a=j*Math.PI/4;
        const along=dx*Math.cos(a)+dy*Math.sin(a);
        if(along>105 && along<1440) roadDist=Math.min(roadDist,Math.abs(-dx*Math.sin(a)+dy*Math.cos(a)));
      }
      const road=roadDist<24 && d>175;
      const water=waterSpots.some(p=>distance(x,y,p.x,p.y)<p.r+hash(tx,ty,3)*16-8);
      let terrain=0;
      if(d>275){
        if(dx<-70&&dy<-50)terrain=1; // northwestern ancient forest
        else if(dx>50&&dy<-70)terrain=2; // northeastern dry highlands
        else if(dx<-50&&dy>65)terrain=3; // southwestern wetlands
        else if(dx>50&&dy>70)terrain=4; // southeastern golden field
      }
      if(water)terrain=6;
      else if(road)terrain=5;
      const item={x,y,tx,ty,d,terrain,obstacle:false};
      const n=hash(tx,ty,91);
      if(d>250 && !road && !water) {
        if(terrain===1 && n>.886 || terrain===0&&n>.960 || terrain===3&&n>.958){
          item.obstacle=true;
          decorations.push({x,y,type:'tree',w:72,h:80,footY:y+16});
        } else if((terrain===2||terrain===4)&&n>.953 || terrain===1&&n<.026){
          item.obstacle=true;
          decorations.push({x,y,type:'rock',w:60,h:68,footY:y+15});
        } else if(terrain===3 && n<.028){
          item.obstacle=true;
          decorations.push({x,y,type:'crystal',w:58,h:66,footY:y+13});
        }
      }
      tiles.push(item);
    }
    createTileImages();
    createMiniBackground();
  }
  function createTileImages() {
    const palette = [
      ['#58815d','#6b9368','#486f57','#84aa74'],
      ['#3e6d52','#517b56','#315c4b','#729465'],
      ['#837752','#94805a','#736b4d','#b6a16e'],
      ['#477369','#5d8573','#42665e','#83a697'],
      ['#748056','#87935c','#64744e','#a4ac78'],
      ['#887964','#9c8b72','#736651','#b2a084'],
      ['#315f74','#38718b','#28596a','#6599a0']
    ];
    for(let kind=0;kind<7;kind++) {
      const variants=[];
      for(let variant=0;variant<6;variant++) {
        const off=document.createElement('canvas');off.width=TILE;off.height=TILE;
        const c=off.getContext('2d');c.imageSmoothingEnabled=false;
        const p=palette[kind], rr=(n)=>hash(variant+17*n,kind+n,23);
        c.fillStyle=p[0];c.fillRect(0,0,TILE,TILE);
        for(let j=0;j<21;j++) {
          const x=Math.floor(rr(j+1)*38),y=Math.floor(rr(j+31)*38),q=rr(j+60);
          c.fillStyle=p[q>.58?1:2];
          c.fillRect(x,y, q>.45?3:2, q>.52?2:3);
        }
        if(kind===5){ // Rustic stone / dirt roads.
          for(let j=0;j<11;j++) {
            const x=Math.floor(rr(j+100)*38),y=Math.floor(rr(j+130)*38);
            c.fillStyle=p[3]; c.fillRect(x,y,4,2);
          }
        }else if(kind===6){
          c.fillStyle='#74a9b1';
          c.fillRect(Math.floor(rr(11)*23)+2,Math.floor(rr(20)*30)+3,11,2);
          c.fillRect(Math.floor(rr(30)*25)+1,Math.floor(rr(50)*30)+4,9,2);
        }else{
          for(let j=0;j<6;j++){
            const x=Math.floor(rr(j+120)*38),y=Math.floor(rr(j+145)*38);
            c.fillStyle=p[3];c.fillRect(x,y,2,3);c.fillRect(x-2,y+2,2,2);
          }
        }
        variants.push(off);
      }
      tileCache[kind]=variants;
    }
  }
  function createMiniBackground() {
    const off=document.createElement('canvas');off.width=176;off.height=176;
    const c=off.getContext('2d');const colors=['#507c60','#3b7253','#877b54','#47756a','#76845a','#a08b70','#447c8d'];
    for(const t of tiles){
      c.fillStyle=colors[t.terrain]; c.fillRect(t.tx*176/MAP,t.ty*176/MAP,Math.ceil(176/MAP),Math.ceil(176/MAP));
    }
    miniBackground=off;
  }
  function loadSprites() {
    const configured=window.PIXEL_ASSETS || {};
    Object.entries(configured).forEach(([id,src])=>{
      if(typeof src!=='string' || !/^([a-z0-9_-]+)$/.test(id))return;
      const img=new Image();
      img.onload=()=>{sprites[id]=img;};
      img.onerror=()=>{};
      img.src=src;
    });
  }
  function drawSprite(id,x,y,w,h) {
    const img=sprites[id];
    if(!img){
      ctx.fillStyle=id==='castle'?'#85989b':id.startsWith('tower')?'#6b8590':id.startsWith('enemy')?'#bb7c68':'#477359';
      ctx.fillRect(Math.floor(x),Math.floor(y),w,h);return;
    }
    ctx.drawImage(img,Math.round(x),Math.round(y),Math.round(w),Math.round(h));
  }
  function reset() {
    Object.assign(state,{
      gold:560,lives:320,wave:0,kills:0,active:false,paused:false,gameOver:false,gameWon:false,
      speed:1,spawnQueue:[],spawnTimer:0,towers:[],enemies:[],shots:[],particles:[],floatTexts:[],
      selection:null,build:null,hover:null,castleFlash:0,threatDirections:[],elapsed:0,killBonus:0,
      houses:[],villagers:[],immigrationClock:0,conversationsStarted:0,conversationsCompleted:0,conversationDurations:[]
    });
    camera.x=C;camera.y=C;camera.zoom=.94;
    enemySerial=0;towerSerial=0;houseSerial=0;villagerSerial=0;
    // Demonstration settlement: one existing hut with one resident. New huts begin empty.
    const starter=findStarterHouse();
    if(starter){const home=createHouse(starter.tx,starter.ty);spawnVillager(home,true);}
    ui.banner.classList.remove('hidden');
    ui.banner.innerHTML='<div class="banner-tag">THE HEART OF THE KINGDOM</div><div class="banner-title">마을과 성을 지켜라</div><div class="banner-desc">초가집을 건설하고 주민이 늘어나는 모습을 지켜보세요.</div>';
    ui.tip.textContent='초가집은 최대 3채 · 집 1채당 주민 최대 3명. 주민을 클릭해 모션을 확인하세요.';
    ui.pauseBtn.textContent='Ⅱ 일시정지';ui.speedBtn.textContent='▶ x1';
    updateUI();updateInspector();
  }
  function toast(msg) {
    ui.toast.textContent=msg;ui.toast.classList.add('show');
    clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>ui.toast.classList.remove('show'),1600);
  }
  function hideBanner(){ui.banner.classList.add('hidden');}
  function selectBuild(type) {
    if(state.gameOver)return;
    if(state.build===type){state.build=null;}else{state.build=type;state.selection=null;}
    hideBanner();updateUI();updateInspector();
    if(state.build)toast(state.build==='house'?'초가집 배치: 3×3 빈 지면을 클릭':TOWERS[state.build].label+' 배치: 원하는 지면을 클릭');
  }
  function canBuild(x,y) {
    if(x<60 || y<60 || x>WORLD-60 || y>WORLD-60) return '월드 경계 밖에는 설치할 수 없습니다.';
    const r=distance(x,y,C,C);
    if(r<166)return '중앙 성 내부에는 설치할 수 없습니다.';
    if(r>1300)return '성채 방어권역 밖입니다.';
    const tile=tileAt(x,y);
    if(tile.terrain===5)return '길 위에는 타워를 지을 수 없습니다.';
    if(tile.terrain===6)return '물 위에는 타워를 지을 수 없습니다.';
    if(tile.obstacle)return '나무나 바위가 있는 곳입니다.';
    for(const tower of state.towers){if(distance(x,y,tower.x,tower.y)<56)return '다른 타워와 너무 가깝습니다.';}
    for(const home of state.houses){if(Math.abs(x-home.x)<90 && Math.abs(y-home.y)<90)return '초가집이 있는 땅에는 타워를 세울 수 없습니다.';}
    for(const v of state.villagers){if(distance(x,y,v.x,v.y)<43 || (v.moveTo&&distance(x,y,cellX(v.moveTo.tx),cellY(v.moveTo.ty))<43))return '주민이 있는 칸에는 타워를 세울 수 없습니다.';}
    return '';
  }
  function snapWorld(wx,wy){return{x:Math.floor(wx/TILE)*TILE+TILE/2,y:Math.floor(wy/TILE)*TILE+TILE/2};}
  function placeTower(type,wx,wy){
    const p=snapWorld(wx,wy), err=canBuild(p.x,p.y),def=TOWERS[type];
    if(err){toast(err);return false;}
    if(state.gold<def.cost){toast('골드가 부족합니다.');return false;}
    const tower={id:++towerSerial,type,x:p.x,y:p.y,level:1,spent:def.cost,reload:rand(.12,.4),facing:0,flash:0};
    state.gold-=def.cost;state.towers.push(tower);state.selection=tower;state.build=null;
    spawnParticles(p.x,p.y,'#ddca8e',12);toast(def.label+' 건설 완료');
    updateUI();updateInspector();return true;
  }
  // Houses reserve exactly 3×3 world tiles, even though their roof protrudes visually.
  function snapHouse(wx,wy){
    const tx=Math.floor(wx/TILE)-1,ty=Math.floor(wy/TILE)-1;
    return{tx,ty,x:(tx+HOUSE_SIZE/2)*TILE,y:(ty+HOUSE_SIZE/2)*TILE};
  }
  function canPlaceHouse(tx,ty){
    if(state.houses.length>=HOUSE_LIMIT)return '초가집은 최대 3채까지 건설할 수 있습니다.';
    if(tx<2||ty<2||tx+HOUSE_SIZE>=MAP-2||ty+HOUSE_SIZE>=MAP-2)return '월드 밖에는 건설할 수 없습니다.';
    const px=(tx+1.5)*TILE,py=(ty+1.5)*TILE;
    if(distance(px,py,C,C)<245)return '중앙 성과 너무 가깝습니다.';
    if(distance(px,py,C,C)>940)return '마을 건설 권역 밖입니다.';
    for(let j=0;j<3;j++)for(let i=0;i<3;i++){
      const cell=tiles[key(tx+i,ty+j)];
      if(cell.obstacle||cell.terrain===6||cell.terrain===5)return '길, 물, 장애물이 없는 3×3 공간이 필요합니다.';
    }
    // Do not build over a resident's occupied or currently reserved destination tile.
    for(const v of state.villagers){
      const cells=[{tx:v.tx,ty:v.ty}];if(v.moveTo)cells.push(v.moveTo);
      if(cells.some(c=>c.tx>=tx-1&&c.tx<tx+HOUSE_SIZE+1&&c.ty>=ty-1&&c.ty<ty+HOUSE_SIZE+1))
        return '주민이 있는 장소에는 집을 지을 수 없습니다.';
    }
    for(const t of state.towers){if(Math.abs(px-t.x)<82&&Math.abs(py-t.y)<82)return '기존 타워와 겹칩니다.';}
    for(const h of state.houses){if(Math.abs(px-h.x)<120&&Math.abs(py-h.y)<120)return '다른 집과 겹칩니다.';}
    return '';
  }
  function createHouse(tx,ty){
    const home={id:++houseSerial,type:'house',tx,ty,x:(tx+1.5)*TILE,y:(ty+1.5)*TILE,level:1};
    state.houses.push(home);return home;
  }
  function findStarterHouse(){
    const sites=[[-310,175],[320,135],[-310,-155],[335,-175],[-390,210],[390,210]];
    for(const [dx,dy] of sites){const s=snapHouse(C+dx,C+dy);if(!canPlaceHouse(s.tx,s.ty))return s;}
    for(let ty=30;ty<=52;ty++)for(let tx=30;tx<=52;tx++){
      if(!canPlaceHouse(tx,ty))return{tx,ty};
    }
    return null;
  }
  function buildHouse(wx,wy){
    const p=snapHouse(wx,wy),err=canPlaceHouse(p.tx,p.ty);
    if(err){toast(err);return false;}
    const h=createHouse(p.tx,p.ty);
    // Construction cost is intentionally not set until the user determines gold rules.
    state.selection=h;state.build=null;
    spawnParticles(h.x,h.y+36,'#f8d78c',16);
    toast('초가집 건설 완료 · 주민이 점차 입주합니다.');
    updateUI();updateInspector();return true;
  }
  function homePopulation(home){return state.villagers.filter(v=>v.homeId===home.id).length;}
  const cellX=tx=>tx*TILE+TILE/2, cellY=ty=>ty*TILE+TILE/2;
  function npcPassableCell(tx,ty){
    if(tx<1||ty<1||tx>=MAP-1||ty>=MAP-1)return false;
    const x=cellX(tx),y=cellY(ty),t=tiles[key(tx,ty)];
    if(!t||t.terrain===6||t.obstacle)return false;
    if(Math.abs(x-C)<137&&Math.abs(y-C)<118)return false;
    for(const h of state.houses){if(Math.abs(x-h.x)<63&&Math.abs(y-h.y)<65)return false;}
    for(const tower of state.towers){if(distance(x,y,tower.x,tower.y)<32)return false;}
    // Semi-open-world village roaming: keep civilian wandering inside settlement region.
    if(distance(x,y,C,C)>945)return false;
    return true;
  }
  function tileReserved(tx,ty,exceptId=null){
    return state.villagers.some(v=>v.id!==exceptId &&
      (v.tx===tx&&v.ty===ty || v.moveTo&&v.moveTo.tx===tx&&v.moveTo.ty===ty));
  }
  function findNpcSpawnTile(home){
    // Prefer a free adjacent tile near a neighbor from the same home, making greetings possible.
    const companions=state.villagers.filter(v=>v.homeId===home.id);
    const candidates=[];
    if(companions.length){
      for(const friend of companions){
        const anchor=friend.moveTo||friend;
        for(const dir of NPC_DIRECTIONS){
          const tx=anchor.tx+dir.dx,ty=anchor.ty+dir.dy;
          if(npcPassableCell(tx,ty)&&!tileReserved(tx,ty))candidates.push({tx,ty});
        }
      }
    }
    if(candidates.length)return candidates[Math.floor(rand(0,candidates.length))];
    const centerX=Math.floor(home.x/TILE),centerY=Math.floor(home.y/TILE);
    // Growing rings ensure there are no accidental double occupancy spawns.
    for(let radius=3;radius<=9;radius++){
      const free=[];
      for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){
        if(Math.max(Math.abs(dx),Math.abs(dy))!==radius)continue;
        const tx=centerX+dx,ty=centerY+dy;
        if(npcPassableCell(tx,ty)&&!tileReserved(tx,ty))free.push({tx,ty});
      }
      if(free.length)return free[Math.floor(rand(0,free.length))];
    }
    return null;
  }
  function spawnVillager(home,starting=false){
    if(!home||homePopulation(home)>=HOUSE_CAPACITY)return null;
    const tile=findNpcSpawnTile(home);
    if(!tile)return null; // Wait for a free tile, never stack villagers.
    const counts={male:state.villagers.filter(v=>v.gender==='male').length,
      female:state.villagers.filter(v=>v.gender==='female').length};
    const gender=starting?'male':counts.female<counts.male?'female':counts.male<counts.female?'male':(Math.random()<.5?'male':'female');
    const v={id:++villagerSerial,type:'villager',gender,homeId:home.id,
      tx:tile.tx,ty:tile.ty,x:cellX(tile.tx),y:cellY(tile.ty),moveTo:null,
      dir:'down',mode:'idle',walkTime:0,action:'',actionTime:0,
      idleTime:starting?1.2:state.villagers.some(o=>o.homeId===home.id)?rand(1.3,2.2):rand(.35,1.3),speed:rand(39,51),
      bubble:'',bubbleTime:0,partnerId:null,chatTime:0,chatDuration:0,chatCooldown:0};
    state.villagers.push(v);
    if(!starting){spawnParticles(v.x,v.y-20,'#cfedb6',9);floating(v.x,v.y-70,'새 주민 +1','#e9f4b0');}
    return v;
  }
  function selectHouseBuild(){
    if(state.gameOver)return;
    if(state.houses.length>=HOUSE_LIMIT){toast('초가집은 이미 3채입니다.');return;}
    selectBuild('house');
  }
  function triggerNpcPose(v,pose){
    if(!v||!NPC_POSES.includes(pose))return false;
    if(v.partnerId!==null)return false; // Paired conversations cannot be interrupted.
    if(v.moveTo){v.x=cellX(v.tx);v.y=cellY(v.ty);v.moveTo=null;}
    v.mode='emote';v.action=pose;v.actionTime=pose.startsWith('talking')?3.2:2.1;
    v.bubbleTime=1.55;
    v.bubble=({surprised:'!',happy:'♪',thinking:'…',greeting_wave:'안녕!',greeting_bow:'꾸벅!',talking_01:'안녕하세요!',talking_02:'반가워요!'})[pose]||'';
    updateInspector();return true;
  }
  function pickNpcStep(v){
    const dirs=[...NPC_DIRECTIONS];
    // Semi-random movement: occasional persistence, otherwise random orthogonal tile step.
    if(Math.random()<.35)dirs.sort((a,b)=>(a.dir===v.dir?-1:b.dir===v.dir?1:0));
    else for(let i=dirs.length-1;i>0;i--){const j=Math.floor(rand(0,i+1));[dirs[i],dirs[j]]=[dirs[j],dirs[i]];}
    for(const dir of dirs){
      const tx=v.tx+dir.dx,ty=v.ty+dir.dy;
      if(!npcPassableCell(tx,ty)||tileReserved(tx,ty,v.id))continue;
      v.dir=dir.dir;
      return {tx,ty};
    }
    return null;
  }
  function faceOther(v,other){
    const dx=other.tx-v.tx,dy=other.ty-v.ty;
    v.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up');
  }
  function startNpcChat(a,b){
    if(a.partnerId!==null||b.partnerId!==null)return false;
    const duration=rand(CHAT_MIN_SECONDS,CHAT_MAX_SECONDS);
    for(const [v,partner] of [[a,b],[b,a]]){
      v.mode='conversation';v.action='talking_01';v.actionTime=0;v.moveTo=null;
      v.partnerId=partner.id;v.chatDuration=duration;v.chatTime=duration;
      v.chatCooldown=0;v.bubble='···';v.bubbleTime=duration;
      faceOther(v,partner);
    }
    state.conversationsStarted++;
    state.conversationDurations.push(Number(duration.toFixed(3)));
    if(state.conversationDurations.length>24)state.conversationDurations.shift();
    if(state.selection===a||state.selection===b)updateInspector();
    return true;
  }
  function endNpcChat(a,b){
    for(const v of [a,b]){
      v.partnerId=null;v.chatTime=0;v.chatDuration=0;
      v.action='';v.mode='idle';v.bubble='';v.bubbleTime=0;
      v.idleTime=rand(.08,.46);v.chatCooldown=rand(9,14);
    }
    state.conversationsCompleted++;
    if(state.selection===a||state.selection===b)updateInspector();
  }
  function stepVillagers(dt){
    if(!state.houses.length)return;
    state.immigrationClock+=dt;
    if(state.immigrationClock>=ARRIVAL_SECONDS){
      state.immigrationClock-=ARRIVAL_SECONDS;
      const available=state.houses.filter(h=>homePopulation(h)<HOUSE_CAPACITY);
      if(available.length){
        const h=available.reduce((best,h)=>homePopulation(h)<homePopulation(best)?h:best,available[0]);
        spawnVillager(h);
        if(state.selection===h)updateInspector();
      }
    }
    const residents=state.villagers;
    // Conversations own both participants, updated once per pair per frame.
    for(const v of residents){
      v.bubbleTime=Math.max(0,v.bubbleTime-dt);
      v.chatCooldown=Math.max(0,v.chatCooldown-dt);
      if(v.partnerId!==null){
        if(v.id>v.partnerId)continue;
        const partner=residents.find(other=>other.id===v.partnerId);
        if(!partner){v.partnerId=null;v.chatTime=0;v.action='';continue;}
        v.chatTime-=dt;partner.chatTime=v.chatTime;
        if(v.chatTime<=0)endNpcChat(v,partner);
        continue;
      }
      if(v.actionTime>0){
        v.actionTime-=dt;
        if(v.actionTime<=0){v.action='';v.mode='idle';v.idleTime=rand(.2,.8);}
        continue;
      }
      if(v.moveTo){
        const goalX=cellX(v.moveTo.tx),goalY=cellY(v.moveTo.ty);
        const d=distance(v.x,v.y,goalX,goalY);
        const step=Math.min(d,v.speed*dt);
        if(d>0){v.x+=(goalX-v.x)*step/d;v.y+=(goalY-v.y)*step/d;}
        v.walkTime+=dt;
        if(d<=step+.01){
          v.tx=v.moveTo.tx;v.ty=v.moveTo.ty;
          v.x=goalX;v.y=goalY;v.moveTo=null;
          v.mode='idle';v.idleTime=rand(.1,.8);
        }
        continue;
      }
      v.idleTime-=dt;
      if(v.idleTime<=0){
        const chance=Math.random();
        if(chance<.09){
          triggerNpcPose(v,NPC_EMOTE_POSES[Math.floor(rand(0,NPC_EMOTE_POSES.length))]);
        } else if(chance<.23){v.idleTime=rand(.6,1.8);}
        else {
          const dest=pickNpcStep(v);
          if(dest){v.moveTo=dest;v.mode='walk';}else{v.mode='idle';v.idleTime=rand(.5,1.4);}
        }
      }
    }
    // Start chat whenever two unoccupied, stable, orthogonally adjacent grid cells meet.
    for(let i=0;i<residents.length;i++){
      const a=residents[i];
      if(a.partnerId!==null||a.moveTo||a.actionTime>0||a.chatCooldown>0)continue;
      for(let j=i+1;j<residents.length;j++){
        const b=residents[j];
        if(b.partnerId!==null||b.moveTo||b.actionTime>0||b.chatCooldown>0)continue;
        if(Math.abs(a.tx-b.tx)+Math.abs(a.ty-b.ty)===1){startNpcChat(a,b);break;}
      }
    }
  }
  function drawHouse(h){
    const w=136,hh=164;
    drawSprite('house_thatch',h.x-w/2,h.y-hh+38,w,hh);
    if(state.selection===h){
      ctx.lineWidth=2;ctx.strokeStyle='#f9db95';ctx.strokeRect(h.tx*TILE,h.ty*TILE,120,120);
      ctx.fillStyle='#1b302bdc';ctx.fillRect(h.x-43,h.y-124,86,19);
      ctx.textAlign='center';ctx.font='bold 12px Consolas,monospace';ctx.fillStyle='#f5e8bd';
      ctx.fillText('주민 '+homePopulation(h)+'/3',h.x,h.y-111);
    }
  }
  function drawNpcFrame(image,sx,sy,frameWidth,frameHeight,bounds,x,y){
    if(!image||!bounds)return false;
    const [left,top,right,bottom]=bounds;
    const sourceWidth=right-left,sourceHeight=bottom-top;
    const height=NPC_DRAW_HEIGHT,width=Math.round(sourceWidth/sourceHeight*height);
    // Trim transparent margins, preserve proportions, and anchor every frame at the same feet.
    ctx.drawImage(image,sx+left,sy+top,sourceWidth,sourceHeight,
      Math.round(x-width/2),Math.round(y-height),width,height);
    return true;
  }
  function drawNpc(v){
    const dirIndex={down:0,up:1,left:2,right:3};
    const spec=NPC_SPECS[v.gender]||NPC_SPECS.male;
    const imgs=npcImages[v.gender]||npcImages.male;
    ctx.fillStyle='#18272277';ctx.beginPath();ctx.ellipse(v.x,v.y-2,15,4,0,0,Math.PI*2);ctx.fill();
    let drawn=false;
    if((v.partnerId!==null||v.action)&&imgs.emotes){
      const pose=(v.partnerId!==null||v.action.startsWith('talking'))
        ?(Math.floor(state.elapsed*NPC_TALK_FPS+v.id)%2?'talking_01':'talking_02') : v.action;
      // The female source has a single greeting. Preserve its original pose for both manual greetings.
      const action=v.gender==='female'&&pose==='greeting_bow'?'greeting_wave':pose;
      const emote=spec.emotes,col=emote.poses.indexOf(action);
      if(col>=0)drawn=drawNpcFrame(imgs.emotes,col*emote.frameW,0,emote.frameW,emote.frameH,
        emote.bounds[col],v.x,v.y);
    }
    if(!drawn&&v.moveTo&&imgs.walk){
      const walk=spec.walk,row=dirIndex[v.dir],col=Math.floor(v.walkTime*NPC_WALK_FPS)%walk.frames;
      drawn=drawNpcFrame(imgs.walk,col*walk.frameW,row*walk.frameH,walk.frameW,walk.frameH,
        walk.bounds[row][col],v.x,v.y);
    }
    if(!drawn&&imgs.idle){
      const idle=spec.idle;
      drawn=drawNpcFrame(imgs.idle,0,0,idle.frameW,idle.frameH,idle.bounds,v.x,v.y);
    }
    if(!drawn){ctx.fillStyle=v.gender==='female'?'#f1b59a':'#d8a474';ctx.fillRect(v.x-9,v.y-40,18,38);}
    if(v.bubbleTime>0&&v.bubble){
      ctx.font='bold 12px sans-serif';const width=Math.min(110,Math.max(27,ctx.measureText(v.bubble).width+15));
      ctx.fillStyle='#18272ee6';ctx.fillRect(v.x-width/2,v.y-87,width,23);
      ctx.strokeStyle='#f9db9a';ctx.lineWidth=1;ctx.strokeRect(v.x-width/2,v.y-87,width,23);
      ctx.fillStyle='#fff2dc';ctx.textAlign='center';ctx.fillText(v.bubble,v.x,v.y-71);
    }
    if(state.selection===v){ctx.strokeStyle='#ffe3a0';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(v.x,v.y-3,24,10,0,0,Math.PI*2);ctx.stroke();}
  }
  function towerStats(t){
    const def=TOWERS[t.type];return{
      damage:Math.round(def.damage*(1+(t.level-1)*.48)),
      range:def.range+(t.level-1)*15,
      cooldown:def.cooldown*(1-(t.level-1)*.10),
      price:Math.round(def.cost*(.72+.27*(t.level-1)))
    };
  }
  function upgradeTower(){
    const t=state.selection;if(!t||t.level>=3)return;
    const price=towerStats(t).price;
    if(state.gold<price){toast('업그레이드할 골드가 부족합니다.');return;}
    state.gold-=price;t.spent+=price;t.level++;
    spawnParticles(t.x,t.y,'#d2c887',18);toast('타워 레벨 '+t.level+' 업그레이드!');updateInspector();updateUI();
  }
  function sellTower(){
    const t=state.selection;if(!t)return;
    const back=Math.round(t.spent*.65);state.gold+=back;
    state.towers.splice(state.towers.indexOf(t),1);state.selection=null;
    spawnParticles(t.x,t.y,'#a4bfc1',10);toast('판매 +' + back + '골드');
    updateUI();updateInspector();
  }
  function updateInspector(){
    const t=state.selection;
    if(!t){
      ui.inspector.innerHTML='<div class="empty-inspector"><div class="empty-glyph">⌖</div><strong>선택된 타워 없음</strong><span>타워를 건설하거나 기존 타워를 클릭하세요.</span></div>';
      return;
    }
    if(t.type==='house'){
      ui.inspector.innerHTML=`<div class="inspector-title"><strong>하급 초가집</strong><span class="level">주거 건물</span></div>
      <div class="inspector-stats"><div><span>건설 면적</span><strong>3 × 3칸</strong></div><div><span>입주 인원</span><strong>${homePopulation(t)} / 3명</strong></div>
      <div><span>초가집 개수</span><strong>${state.houses.length} / 3채</strong></div><div><span>진화 시스템</span><strong>준비 중</strong></div></div>
      <div class="inspector-actions"><button type="button" class="btn btn-primary" disabled title="진화 조건 미확정">🔒 진화 잠금</button></div>`;
      return;
    }
    if(t.type==='villager'){
      ui.inspector.innerHTML=`<div class="inspector-title"><strong>${t.gender==='female'?'여성':'남성'} 주민 #${t.id}</strong><span class="level">마을 주민</span></div>
      <p class="npc-hint">${t.partnerId!==null?`주민 #${t.partnerId}과 대화 중 · 남은 ${Math.max(0,t.chatTime).toFixed(1)}초`:`격자 (${t.tx}, ${t.ty}) · 한 칸에 주민 한 명 · 인접하면 5~10초 자동 대화`}<br>수동 감정 표현은 경제 수치를 변경하지 않습니다.</p>
      <div class="npc-actions"><button type="button" data-pose="greeting_wave">👋 손인사</button>${t.gender==='male'?'<button type="button" data-pose="greeting_bow">🙇 숙여인사</button>':''}<button type="button" data-pose="happy">😊 기쁨</button><button type="button" data-pose="surprised">❗ 놀람</button><button type="button" data-pose="thinking">💭 생각</button><button type="button" data-pose="talking_01">💬 대화</button></div>`;
      return;
    }
    const def=TOWERS[t.type],stats=towerStats(t),max=t.level===3;
    ui.inspector.innerHTML=`<div class="inspector-title"><strong>${def.label}</strong><span class="level">LV.${t.level} / 3</span></div>
    <div class="inspector-stats"><div><span>공격력</span><strong>${stats.damage}</strong></div><div><span>사거리</span><strong>${stats.range}</strong></div>
    <div><span>공격 간격</span><strong>${stats.cooldown.toFixed(2)}초</strong></div><div><span>총 투자</span><strong>◆ ${t.spent}</strong></div></div>
    <div class="inspector-actions"><button type="button" class="btn btn-primary" data-action="upgrade" ${max||state.gold<stats.price?'disabled':''}>${max?'최고 레벨':'강화 ◆ '+stats.price}</button><button type="button" class="btn btn-ghost" data-action="sell">판매 ◆ ${Math.round(t.spent*.65)}</button></div>`;
  }
  function updateUI(){
    ui.gold.textContent=Math.floor(state.gold);ui.lives.textContent=Math.max(0,Math.ceil(state.lives));
    ui.pop.textContent=state.villagers.length;ui.capacity.textContent=state.houses.length*HOUSE_CAPACITY;
    ui.houseCount.textContent=state.houses.length+'/'+HOUSE_LIMIT;
    ui.houseButton.disabled=state.houses.length>=HOUSE_LIMIT||state.gameOver;
    ui.houseButton.setAttribute('aria-pressed',String(state.build==='house'));
    ui.houseSub.textContent=state.houses.length>=HOUSE_LIMIT?'3/3 건설 제한 도달':'최대 3채 · 3×3칸 · 비용 미정';
    ui.wave.textContent=state.wave;ui.kills.textContent=state.kills;
    ui.pauseBtn.textContent=state.paused?'▶ 재개':'Ⅱ 일시정지';
    ui.zoom.textContent=Math.round(camera.zoom*100)+'%';
    ui.waveBtn.disabled=state.active||state.gameOver;
    ui.waveBtn.textContent=state.gameOver?'⚑ 성채 함락':state.active?'⚔ 침공 진행 중':'▶ 웨이브 '+(state.wave+1)+' 시작';
    ui.status.textContent=state.gameOver?'성채가 함락되었습니다':state.paused?'일시정지 중':state.active?'성 공격 중 · 생존 적 '+(state.enemies.length+state.spawnQueue.length)+'명':'방어 준비 · 타워 '+state.towers.length+'개 · 주민 '+state.villagers.length+'명';
    ui.liveDot.classList.toggle('active',state.active&&!state.paused);
    ui.threat.classList.toggle('under-attack',state.active);
    if(state.gameOver)ui.threatText.textContent='최종 방어 실패 · 웨이브 '+state.wave;
    else if(state.active){
      const dirs=state.threatDirections.map(i=>DIRS[i]);
      ui.threatText.textContent=dirs.join(' · ')+'에서 침공!';
    }else ui.threatText.textContent='중앙 성 방어 준비 · 사방 경계';
    for(const button of ui.towerList.querySelectorAll('[data-tower]')){
      const type=button.dataset.tower;
      button.setAttribute('aria-pressed',String(state.build===type));
      button.classList.toggle('unaffordable',state.gold<TOWERS[type].cost);
    }
    if(state.selection)updateInspector();
  }
  function startWave(){
    if(state.active||state.gameOver)return;
    hideBanner();state.wave++;state.active=true;state.paused=false;
    state.spawnQueue=[];state.spawnTimer=.35;
    const w=state.wave,count=Math.min(8+w*2,46);
    // All four cardinal directions from wave 1; diagonals join from wave 3.
    const sectors=w<3?[0,2,4,6]:[0,1,2,3,4,5,6,7];
    const offset=(w*3)%sectors.length;
    state.threatDirections=sectors.slice();
    for(let i=0;i<count;i++){
      let kind='grunt';
      if(w>=2&&i%4===2)kind='runner';
      if(w>=3&&i%7===5)kind='brute';
      if(w>=5&&i%9===4)kind='brute';
      state.spawnQueue.push({kind,dir:sectors[(i+offset)%sectors.length]});
    }
    if(w%5===0){state.spawnQueue.push({kind:'boss',dir:sectors[w%sectors.length]});}
    state.spawnQueue.sort(()=>Math.random()-.5);
    ui.tip.textContent='빨간 화살표와 미니맵으로 침공 방향을 확인하세요!';
    toast('웨이브 '+w+' : '+(w<3?'4방향':'8방향')+' 침공 시작');
    updateUI();
  }
  function spawnEnemy(data){
    const def=FOES[data.kind];
    const a=-Math.PI/2+data.dir*Math.PI/4+rand(-.10,.10);
    const r=rand(770,890);
    const hp=Math.round(def.hp*(1+Math.max(0,state.wave-1)*.20));
    state.enemies.push({
      id:++enemySerial,kind:data.kind,x:C+Math.cos(a)*r,y:C+Math.sin(a)*r,
      hp,maxHp:hp,speed:def.speed*(1+Math.min(state.wave*.015,.26)),bounty:def.bounty,leak:def.leak,
      dead:false,slowTimer:0,burnTimer:0,burnDps:0,angle:a,dir:data.dir,step:rand(0,5),flash:0
    });
  }
  function spawnParticles(x,y,color,n){
    for(let i=0;i<n;i++){
      const angle=rand(0,Math.PI*2),force=rand(20,110);
      state.particles.push({x,y,vx:Math.cos(angle)*force,vy:Math.sin(angle)*force,life:rand(.26,.74),max:.74,color,size:rand(2,5)});
    }
    if(state.particles.length>300)state.particles.splice(0,state.particles.length-300);
  }
  function floating(x,y,text,color){state.floatTexts.push({x,y,text,color,life:1.2});}
  function killEnemy(enemy){
    if(enemy.dead)return;
    enemy.dead=true;state.gold+=enemy.bounty;state.kills++;
    spawnParticles(enemy.x,enemy.y,enemy.kind==='boss'?'#e8a4bd':'#c9b484',enemy.kind==='boss'?40:10);
    floating(enemy.x,enemy.y-20,'+'+enemy.bounty+'◆','#e6cc8c');
  }
  function damageEnemy(enemy,amount){
    if(!enemy||enemy.dead)return;
    enemy.hp-=amount;enemy.flash=.11;
    if(enemy.hp<=0)killEnemy(enemy);
  }
  function stepEnemies(dt){
    for(const e of state.enemies){
      if(e.dead)continue;
      e.slowTimer=Math.max(0,e.slowTimer-dt);
      e.flash=Math.max(0,e.flash-dt);
      if(e.burnTimer>0){e.burnTimer-=dt;damageEnemy(e,e.burnDps*dt);if(e.dead)continue;}
      const dx=C-e.x,dy=C-e.y,r=Math.hypot(dx,dy);
      if(r<104){
        e.dead=true;state.lives=Math.max(0,state.lives-e.leak);
        state.castleFlash=.33;spawnParticles(e.x,e.y,'#ffb18e',12);
        floating(e.x,e.y,'-'+e.leak+' ♥','#ff9a8d');
        if(state.lives<=0){gameOver();break;}
        continue;
      }
      const speed=e.speed*(e.slowTimer>0?.46:1);
      const sway=Math.sin(state.elapsed*1.8+e.step)*.07;
      e.x+=(dx/r + (-dy/r)*sway)*speed*dt;
      e.y+=(dy/r + ( dx/r)*sway)*speed*dt;
    }
    state.enemies=state.enemies.filter(e=>!e.dead);
  }
  function stepTowers(dt){
    for(const t of state.towers){
      t.reload-=dt;t.flash=Math.max(0,t.flash-dt);
      if(t.reload>0)continue;
      const stats=towerStats(t);
      let target=null,best=Infinity;
      for(const e of state.enemies){
        if(e.dead)continue;
        const dr=distance(t.x,t.y,e.x,e.y);
        if(dr>stats.range)continue;
        const score=distance(e.x,e.y,C,C)+dr*.045;
        if(score<best){best=score;target=e;}
      }
      if(!target){t.reload=0;continue;}
      t.reload=stats.cooldown;t.flash=.09;
      t.facing=Math.atan2(target.y-t.y,target.x-t.x);
      state.shots.push({x:t.x,y:t.y-17,target,targetId:target.id,type:t.type,damage:stats.damage,
        speed:TOWERS[t.type].shotSpeed,life:2.6,level:t.level});
    }
  }
  function strike(shot,e){
    const def=TOWERS[shot.type];
    if(def.splash){
      for(const enemy of state.enemies){
        if(enemy.dead)continue;
        const dr=distance(e.x,e.y,enemy.x,enemy.y);
        if(dr<=def.splash+(shot.level-1)*7){
          damageEnemy(enemy,shot.damage*(enemy===e?1:.64));
          if(def.burn && !enemy.dead){enemy.burnTimer=Math.max(enemy.burnTimer,2.4);enemy.burnDps=Math.max(enemy.burnDps,def.burn*(1+shot.level*.25));}
        }
      }
    } else {
      damageEnemy(e,shot.damage);
      if(def.slow && !e.dead)e.slowTimer=def.slow+shot.level*.28;
    }
    spawnParticles(e.x,e.y,def.color,shot.type==='cannon'?16:shot.type==='flame'?13:5);
  }
  function stepShots(dt){
    for(const s of state.shots){
      if(s.life<=0)continue;
      s.life-=dt;
      const target=s.target;
      if(!target||target.dead){s.life=-1;continue;}
      const dx=target.x-s.x,dy=(target.y-13)-s.y,d=Math.hypot(dx,dy);
      if(d<s.speed*dt+9){strike(s,target);s.life=-1;continue;}
      s.x+=dx/d*s.speed*dt;s.y+=dy/d*s.speed*dt;
    }
    state.shots=state.shots.filter(s=>s.life>0);
  }
  function stepParticles(dt){
    for(const p of state.particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.max(0,1-dt*3);p.vy*=Math.max(0,1-dt*3);p.life-=dt;}
    for(const t of state.floatTexts){t.y-=27*dt;t.life-=dt;}
    state.particles=state.particles.filter(p=>p.life>0);
    state.floatTexts=state.floatTexts.filter(p=>p.life>0);
    state.castleFlash=Math.max(0,state.castleFlash-dt);
  }
  function finishWave(){
    state.active=false;const bonus=75+state.wave*12;
    state.gold+=bonus;
    floating(C,C-160,'방어 성공! +'+bonus+'◆','#f7db89');
    toast('웨이브 '+state.wave+' 방어 성공! 보너스 +'+bonus+'골드');
    ui.tip.textContent='다음 침공 전 골드로 타워를 확충하고 강화하세요.';
    updateUI();
  }
  function gameOver(){
    if(state.gameOver)return;
    state.gameOver=true;state.active=false;state.paused=false;
    state.spawnQueue=[];
    ui.banner.innerHTML='<div class="banner-tag">DEFENSE FAILED</div><div class="banner-title">중앙 성 함락</div><div class="banner-desc">웨이브 '+state.wave+' · 적 '+state.kills+'명 처치 — 새 게임으로 다시 도전하세요.</div>';
    ui.banner.classList.remove('hidden');
    updateUI();
  }
  function tick(dt){
    state.elapsed+=dt;
    if(state.spawnQueue.length){
      state.spawnTimer-=dt;
      while(state.spawnTimer<=0 && state.spawnQueue.length){
        spawnEnemy(state.spawnQueue.shift());state.spawnTimer+=.56/(1+Math.min(state.wave*.04,.55));
      }
    }
    stepEnemies(dt);
    if(state.gameOver)return;
    stepTowers(dt);stepShots(dt);
    if(state.active&&!state.spawnQueue.length&&!state.enemies.length)finishWave();
  }
  function viewBounds(){
    return {left:camera.x-CW/(2*camera.zoom),right:camera.x+CW/(2*camera.zoom),
      top:camera.y-CH/(2*camera.zoom),bottom:camera.y+CH/(2*camera.zoom)};
  }
  function boundCamera(){
    const halfW=CW/(camera.zoom*2),halfH=CH/(camera.zoom*2);
    camera.x=clamp(camera.x,halfW,WORLD-halfW);
    camera.y=clamp(camera.y,halfH,WORLD-halfH);
  }
  function screenToWorld(sx,sy){return{x:camera.x+(sx-CW/2)/camera.zoom,y:camera.y+(sy-CH/2)/camera.zoom};}
  function worldToScreen(x,y){return{x:(x-camera.x)*camera.zoom+CW/2,y:(y-camera.y)*camera.zoom+CH/2};}
  function setZoom(z,sx=CW/2,sy=CH/2){
    const pos=screenToWorld(sx,sy);
    camera.zoom=clamp(z,MINZOOM,MAXZOOM);
    camera.x=pos.x-(sx-CW/2)/camera.zoom;
    camera.y=pos.y-(sy-CH/2)/camera.zoom;
    boundCamera();ui.zoom.textContent=Math.round(camera.zoom*100)+'%';
  }
  function moveCamera(dt){
    const speed=690/camera.zoom, dx=(pressed.has('d')||pressed.has('arrowright')?1:0)-(pressed.has('a')||pressed.has('arrowleft')?1:0),
      dy=(pressed.has('s')||pressed.has('arrowdown')?1:0)-(pressed.has('w')||pressed.has('arrowup')?1:0);
    if(dx||dy){const len=Math.hypot(dx,dy);camera.x+=speed*dt*dx/len;camera.y+=speed*dt*dy/len;boundCamera();}
  }
  function drawGround(){
    const b=viewBounds();
    const c1=clamp(Math.floor(b.left/TILE)-1,0,MAP-1),c2=clamp(Math.ceil(b.right/TILE)+1,0,MAP-1);
    const r1=clamp(Math.floor(b.top/TILE)-1,0,MAP-1),r2=clamp(Math.ceil(b.bottom/TILE)+1,0,MAP-1);
    for(let y=r1;y<=r2;y++)for(let x=c1;x<=c2;x++){
      const t=tiles[key(x,y)];
      ctx.drawImage(tileCache[t.terrain][Math.floor(hash(x,y,13)*6)],x*TILE,y*TILE);
      if(t.d>195&&t.d<218&&t.terrain!==5){
        ctx.fillStyle='#a3a68d';
        if(hash(x,y,91)>.45)ctx.fillRect(x*TILE+14,y*TILE+16,13,3);
      }
    }
    // Castle forecourt and cardinal approach markings.
    ctx.fillStyle='#9e9980';ctx.fillRect(C-98,C-68,196,137);
    ctx.fillStyle='#7a887b';
    for(let y=C-56;y<C+70;y+=21)for(let x=C-88;x<C+95;x+=27){
      ctx.fillRect(x+((y/21)%2)*6,y,21,2);
    }
    ctx.strokeStyle='#b9ba9b';ctx.lineWidth=3;
    ctx.strokeRect(C-95,C-67,190,135);
  }
  function drawDepthItems(){
    const b=viewBounds(),all=[];
    for(const d of decorations)if(d.x>b.left-90&&d.x<b.right+90&&d.y>b.top-100&&d.y<b.bottom+100) all.push({y:d.footY,kind:'decor',obj:d});
    for(const h of state.houses)if(h.x>b.left-120&&h.x<b.right+120&&h.y>b.top-180&&h.y<b.bottom+140)all.push({y:h.y+48,kind:'house',obj:h});
    for(const v of state.villagers)if(v.x>b.left-100&&v.x<b.right+100&&v.y>b.top-120&&v.y<b.bottom+100)all.push({y:v.y,kind:'npc',obj:v});
    for(const t of state.towers)if(t.x>b.left-90&&t.x<b.right+90&&t.y>b.top-100&&t.y<b.bottom+100)all.push({y:t.y+13,kind:'tower',obj:t});
    for(const e of state.enemies)if(e.x>b.left-100&&e.x<b.right+100&&e.y>b.top-110&&e.y<b.bottom+110)all.push({y:e.y+17,kind:'enemy',obj:e});
    if(C>b.left-160&&C<b.right+160&&C>b.top-200&&C<b.bottom+170)all.push({y:C+83,kind:'castle'});
    all.sort((a,b)=>a.y-b.y);
    for(const entry of all){
      if(entry.kind==='decor'){
        const d=entry.obj;drawSprite(d.type,d.x-d.w/2,d.y-d.h+18,d.w,d.h);
      }else if(entry.kind==='house')drawHouse(entry.obj);
      else if(entry.kind==='npc')drawNpc(entry.obj);
      else if(entry.kind==='tower')drawTower(entry.obj);
      else if(entry.kind==='enemy')drawEnemy(entry.obj);
      else drawCastle();
    }
  }
  function drawTower(t){
    drawSprite('tower_'+t.type,t.x-41,t.y-62,82,96);
    if(t.flash>0){ctx.fillStyle='#fff0b9';ctx.fillRect(t.x-3,t.y-61,6,6);}
    if(t.level>1){
      ctx.fillStyle='#182c36';ctx.fillRect(t.x-20,t.y+29,40,11);
      ctx.fillStyle='#efce87';ctx.font='bold 10px monospace';ctx.textAlign='center';ctx.fillText('★'.repeat(t.level-1),t.x,t.y+38);
    }
    if(state.selection===t){
      const range=towerStats(t).range;
      ctx.beginPath();ctx.arc(t.x,t.y,range,0,Math.PI*2);
      ctx.fillStyle='rgba(222,232,189,.065)';ctx.fill();
      ctx.strokeStyle='rgba(255,231,166,.68)';ctx.lineWidth=2;ctx.setLineDash([7,6]);ctx.stroke();ctx.setLineDash([]);
      ctx.strokeStyle='#f8d98a';ctx.lineWidth=3;ctx.strokeRect(t.x-24,t.y-20,48,40);
    }
  }
  function drawEnemy(e){
    const types={grunt:[56,63],runner:[55,62],brute:[68,79],boss:[118,134]};
    const wh=types[e.kind],w=wh[0],h=wh[1];
    drawSprite('enemy_'+e.kind,e.x-w/2,e.y-h+20,w,h);
    if(e.flash>0){ctx.fillStyle='#ffedbf';ctx.fillRect(e.x-6,e.y-32,12,3);}
    const ratio=clamp(e.hp/e.maxHp,0,1),barW=e.kind==='boss'?93:47;
    ctx.fillStyle='#1c2b32';ctx.fillRect(e.x-barW/2-2,e.y-h+13,barW+4,9);
    ctx.fillStyle=e.kind==='boss'?'#ec82ab':'#ce6d62';ctx.fillRect(e.x-barW/2,e.y-h+15,Math.round(barW*ratio),5);
    if(e.slowTimer>0){ctx.fillStyle='#94e8f1';ctx.fillRect(e.x-4,e.y+17,8,4);}
    if(e.burnTimer>0){ctx.fillStyle='#ffc568';ctx.fillRect(e.x+7,e.y-14,5,5);}
  }
  function drawCastle(){
    drawSprite('castle',C-138,C-156,276,285);
    if(state.castleFlash>0){
      ctx.fillStyle='rgba(255,103,81,.26)';ctx.fillRect(C-104,C-86,208,197);
    }
    const barW=156;
    ctx.fillStyle='#24323b';ctx.fillRect(C-barW/2-3,C-166,barW+6,15);
    ctx.fillStyle='#6cbc8d';ctx.fillRect(C-barW/2,C-163,Math.round(barW*state.lives/320),9);
    ctx.strokeStyle='#d3d6b2';ctx.lineWidth=1;ctx.strokeRect(C-barW/2,C-163,barW,9);
    ctx.textAlign='center';ctx.fillStyle='#ffebbb';ctx.font='bold 17px Consolas,monospace';
    ctx.fillText('THE BASTION',C,C-175);
  }
  function drawShots(){
    for(const s of state.shots){
      const color=TOWERS[s.type].color;
      ctx.fillStyle='#22303a';ctx.fillRect(Math.round(s.x-4),Math.round(s.y-4),9,9);
      ctx.fillStyle=color;ctx.fillRect(Math.round(s.x-3),Math.round(s.y-3),6,6);
      if(s.type==='frost'){ctx.fillStyle='#bafdf5';ctx.fillRect(s.x-6,s.y,12,2);ctx.fillRect(s.x,s.y-6,2,12);}
      if(s.type==='flame'){ctx.fillStyle='#fa9550';ctx.fillRect(s.x-4,s.y-7,8,3);}
    }
  }
  function drawParticles(){
    for(const p of state.particles){ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.fillRect(Math.round(p.x),Math.round(p.y),Math.ceil(p.size),Math.ceil(p.size));}
    ctx.globalAlpha=1;
    for(const t of state.floatTexts){ctx.globalAlpha=clamp(t.life/.6,0,1);ctx.font='bold 14px Consolas,monospace';ctx.textAlign='center';ctx.fillStyle='#192b32';ctx.fillText(t.text,t.x+2,t.y+2);ctx.fillStyle=t.color;ctx.fillText(t.text,t.x,t.y);}
    ctx.globalAlpha=1;
  }
  function drawGhost(){
    if(!state.build||!state.hover||state.gameOver)return;
    const p=snapWorld(state.hover.x,state.hover.y);
    if(state.build==='house'){
      const h=snapHouse(state.hover.x,state.hover.y);
      const valid=canPlaceHouse(h.tx,h.ty)==='';
      ctx.fillStyle=valid?'rgba(179,242,179,.2)':'rgba(253,100,96,.24)';
      ctx.fillRect(h.tx*TILE,h.ty*TILE,120,120);
      ctx.strokeStyle=valid?'#e6eaba':'#f59c87';ctx.lineWidth=3;
      ctx.strokeRect(h.tx*TILE,h.ty*TILE,120,120);
      ctx.globalAlpha=.7;drawSprite('house_thatch',h.x-68,h.y-126,136,164);ctx.globalAlpha=1;
      return;
    }
    const range=TOWERS[state.build].range,valid=canBuild(p.x,p.y)===''&&state.gold>=TOWERS[state.build].cost;
    ctx.beginPath();ctx.arc(p.x,p.y,range,0,Math.PI*2);
    ctx.fillStyle=valid?'rgba(166,234,163,.095)':'rgba(249,89,85,.12)';ctx.fill();
    ctx.strokeStyle=valid?'#c9e9aa':'#ed8b7d';ctx.lineWidth=2;ctx.setLineDash([8,6]);ctx.stroke();ctx.setLineDash([]);
    ctx.globalAlpha=.74;drawSprite('tower_'+state.build,p.x-41,p.y-62,82,96);ctx.globalAlpha=1;
    ctx.strokeStyle=valid?'#b9e6ac':'#e78c86';ctx.lineWidth=3;
    ctx.strokeRect(p.x-20,p.y-20,40,40);
  }
  function drawThreatArrows(){
    if(!state.active)return;
    ctx.save();ctx.setTransform(1,0,0,1,0,0);
    const edges=[];
    for(const e of state.enemies){
      const pos=worldToScreen(e.x,e.y);
      if(pos.x>=8&&pos.y>=8&&pos.x<=CW-8&&pos.y<=CH-8)continue;
      const ang=Math.atan2(pos.y-CH/2,pos.x-CW/2);
      const lx=Math.cos(ang),ly=Math.sin(ang);
      const tX=lx>0?(CW-25-CW/2)/lx:lx<0?(25-CW/2)/lx:Infinity;
      const tY=ly>0?(CH-25-CH/2)/ly:ly<0?(25-CH/2)/ly:Infinity;
      const ts=Math.min(tX,tY);
      const x=CW/2+lx*ts,y=CH/2+ly*ts;
      const nearby=edges.find(p=>Math.hypot(p.x-x,p.y-y)<32);
      if(nearby){nearby.n++;continue;}
      edges.push({x,y,angle:ang,n:1});
    }
    for(const p of edges){
      ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle);
      ctx.fillStyle='#271f28';ctx.fillRect(-19,-17,39,33);
      ctx.fillStyle='#ed8d74';ctx.beginPath();ctx.moveTo(15,0);ctx.lineTo(-7,-12);ctx.lineTo(-7,12);ctx.closePath();ctx.fill();
      ctx.restore();
      ctx.fillStyle='#fff6d4';ctx.textAlign='center';ctx.font='bold 12px Consolas,monospace';ctx.fillText(String(p.n),p.x,p.y+24);
    }
    ctx.restore();
  }
  function drawPaused(){
    ctx.save();ctx.setTransform(1,0,0,1,0,0);
    ctx.fillStyle='rgba(16,30,35,.53)';ctx.fillRect(0,0,CW,CH);
    ctx.textAlign='center';ctx.font='bold 35px Consolas,monospace';ctx.fillStyle='#f1e3b8';ctx.fillText('Ⅱ  PAUSED',CW/2,CH/2);
    ctx.font='bold 15px sans-serif';ctx.fillText('일시정지 · 계속하려면 재개 버튼 또는 스페이스',CW/2,CH/2+28);
    ctx.restore();
  }
  function drawMap(){
    ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#3a6459';ctx.fillRect(0,0,CW,CH);
    ctx.setTransform(camera.zoom,0,0,camera.zoom,CW/2-camera.x*camera.zoom,CH/2-camera.y*camera.zoom);
    ctx.imageSmoothingEnabled=false;
    drawGround();drawDepthItems();drawShots();drawParticles();drawGhost();
    ctx.setTransform(1,0,0,1,0,0);
    drawThreatArrows();
    if(state.paused)drawPaused();
  }
  function drawMini(){
    miniCtx.drawImage(miniBackground,0,0);
    const sc=176/WORLD;
    for(const d of decorations){
      if(d.type==='crystal')miniCtx.fillStyle='#9ee1d6';else if(d.type==='rock')miniCtx.fillStyle='#aab3a0';else miniCtx.fillStyle='#315a47';
      miniCtx.fillRect(d.x*sc,d.y*sc,2,2);
    }
    for(const t of state.towers){miniCtx.fillStyle='#fff2c7';miniCtx.fillRect(t.x*sc-1,t.y*sc-1,3,3);}
    for(const h of state.houses){miniCtx.fillStyle='#efb36d';miniCtx.fillRect(h.x*sc-2,h.y*sc-2,5,5);}
    for(const v of state.villagers){miniCtx.fillStyle='#d0fcdb';miniCtx.fillRect(v.x*sc,v.y*sc,2,2);}
    for(const e of state.enemies){miniCtx.fillStyle=e.kind==='boss'?'#f4a5c7':'#f58770';miniCtx.fillRect(e.x*sc-1,e.y*sc-1,e.kind==='boss'?5:3,e.kind==='boss'?5:3);}
    miniCtx.fillStyle='#f3da91';miniCtx.fillRect(C*sc-4,C*sc-4,8,8);
    const b=viewBounds();miniCtx.strokeStyle='#fff2bd';miniCtx.lineWidth=1.6;
    miniCtx.strokeRect(b.left*sc,b.top*sc,(b.right-b.left)*sc,(b.bottom-b.top)*sc);
  }
  function frame(now){
    const realDt=clamp((now-lastFrame)/1000,0,.05);lastFrame=now;
    moveCamera(realDt);
    if(!state.paused&&!state.gameOver){
      const dt=realDt*state.speed;
      if(state.active)tick(dt);
      stepParticles(dt);
      stepVillagers(dt);
    }
    drawMap();drawMini();
    uiTimer+=realDt;
    if(uiTimer>.33){uiTimer=0;updateUI();}
    requestAnimationFrame(frame);
  }
  function canvasCoord(ev){
    const r=canvas.getBoundingClientRect();
    return{x:(ev.clientX-r.left)*CW/r.width,y:(ev.clientY-r.top)*CH/r.height};
  }
  function handleTap(pos){
    if(state.gameOver)return;
    const w=screenToWorld(pos.x,pos.y);
    let nearest=null,best=45;
    for(const t of state.towers){const d=distance(w.x,w.y,t.x,t.y);if(d<best){best=d;nearest=t;}}
    if(state.build){if(state.build==='house')buildHouse(w.x,w.y);else placeTower(state.build,w.x,w.y);return;}
    // Prefer the resident when multiple sprites overlap under the cursor.
    for(const v of state.villagers){
      if(Math.abs(w.x-v.x)<27&&w.y<v.y+10&&w.y>v.y-72){
        state.selection=v;if(v.partnerId===null)triggerNpcPose(v,'greeting_wave');updateInspector();return;
      }
    }
    if(!nearest){for(const h of state.houses){
      if(Math.abs(w.x-h.x)<72&&w.y>h.y-126&&w.y<h.y+48){nearest=h;break;}
    }}
    state.selection=nearest;updateInspector();
  }
  canvas.addEventListener('pointerdown',ev=>{
    if(ev.button!==0&&ev.button!==2)return;
    const p=canvasCoord(ev);pointer={active:true,id:ev.pointerId,x:p.x,y:p.y,lastX:p.x,lastY:p.y,drag:false,button:ev.button};
    canvas.setPointerCapture(ev.pointerId);
    ev.preventDefault();
  });
  canvas.addEventListener('pointermove',ev=>{
    const p=canvasCoord(ev);state.hover=screenToWorld(p.x,p.y);
    if(!pointer.active||pointer.id!==ev.pointerId)return;
    if(distance(p.x,p.y,pointer.x,pointer.y)>8)pointer.drag=true;
    if(pointer.drag){camera.x-=(p.x-pointer.lastX)/camera.zoom;camera.y-=(p.y-pointer.lastY)/camera.zoom;boundCamera();}
    pointer.lastX=p.x;pointer.lastY=p.y;
  });
  function endPointer(ev){
    if(!pointer.active||pointer.id!==ev.pointerId)return;
    const p=canvasCoord(ev);
    if(!pointer.drag){
      if(pointer.button===2){state.build=null;state.selection=null;updateUI();updateInspector();}
      else handleTap(p);
    }
    pointer.active=false;
    try{canvas.releasePointerCapture(ev.pointerId);}catch{}
  }
  canvas.addEventListener('pointerup',endPointer);
  canvas.addEventListener('pointercancel',()=>{pointer.active=false;});
  canvas.addEventListener('pointerleave',()=>{state.hover=null;});
  canvas.addEventListener('contextmenu',e=>e.preventDefault());
  canvas.addEventListener('wheel',ev=>{
    ev.preventDefault();const p=canvasCoord(ev);
    setZoom(camera.zoom*(ev.deltaY<0?1.11:.9),p.x,p.y);
  },{passive:false});
  miniCanvas.addEventListener('pointerdown',ev=>{
    const r=miniCanvas.getBoundingClientRect();
    camera.x=clamp((ev.clientX-r.left)/r.width*WORLD,0,WORLD);
    camera.y=clamp((ev.clientY-r.top)/r.height*WORLD,0,WORLD);
    boundCamera();
  });
  ui.home.addEventListener('click',()=>{camera.x=C;camera.y=C;boundCamera();});
  ui.zoomIn.addEventListener('click',()=>setZoom(camera.zoom*1.15));
  ui.zoomOut.addEventListener('click',()=>setZoom(camera.zoom/1.15));
  ui.houseButton.addEventListener('click',selectHouseBuild);
  ui.towerList.addEventListener('click',ev=>{
    const button=ev.target.closest('[data-tower]');if(button)selectBuild(button.dataset.tower);
  });
  ui.inspector.addEventListener('click',ev=>{
    const button=ev.target.closest('[data-action]');
    const pose=ev.target.closest('[data-pose]');
    if(pose&&state.selection&&state.selection.type==='villager'){if(!triggerNpcPose(state.selection,pose.dataset.pose))toast('다른 주민과 대화하는 중입니다.');return;}
    if(!button)return;
    if(button.dataset.action==='upgrade')upgradeTower();
    if(button.dataset.action==='sell')sellTower();
  });
  ui.waveBtn.addEventListener('click',startWave);
  ui.pauseBtn.addEventListener('click',()=>{if(state.gameOver)return;state.paused=!state.paused;updateUI();});
  ui.speedBtn.addEventListener('click',()=>{state.speed=state.speed===1?2:1;ui.speedBtn.textContent='▶ x'+state.speed;});
  ui.restartBtn.addEventListener('click',()=>{
    if(ui.confirm && typeof ui.confirm.showModal==='function')ui.confirm.showModal();
    else if(window.confirm('모든 진행 상황을 초기화하고 새 게임을 시작할까요?'))reset();
  });
  ui.confirm.addEventListener('close',()=>{if(ui.confirm.returnValue==='restart')reset();});
  window.addEventListener('keydown',ev=>{
    const k=ev.key.toLowerCase();
    if(['arrowleft','arrowright','arrowup','arrowdown',' '].includes(k))ev.preventDefault();
    if(ev.repeat && !['w','a','s','d','arrowleft','arrowright','arrowup','arrowdown'].includes(k))return;
    pressed.add(k);
    if(['1','2','3','4'].includes(k))selectBuild(['arrow','cannon','frost','flame'][Number(k)-1]);
    else if(k==='5')selectHouseBuild();
    else if(k==='escape'){state.build=null;state.selection=null;updateUI();updateInspector();}
    else if(k==='h'){camera.x=C;camera.y=C;boundCamera();}
    else if(k===' '||k==='p'){if(!state.gameOver){state.paused=!state.paused;updateUI();}}
    else if(k==='enter'&&!state.active&&!state.gameOver)startWave();
    else if(k==='+'||k==='=')setZoom(camera.zoom*1.13);
    else if(k==='-')setZoom(camera.zoom/1.13);
  });
  window.addEventListener('keyup',ev=>pressed.delete(ev.key.toLowerCase()));
  window.addEventListener('blur',()=>pressed.clear());

  // Read-only snapshot for smoke tests; game logic remains independent of devtools.
  window.PIXEL_BASTION = Object.freeze({
    snapshot:()=>({gold:state.gold,lives:state.lives,wave:state.wave,kills:state.kills,
      towerCount:state.towers.length,enemyCount:state.enemies.length,spawnCount:state.spawnQueue.length,
      active:state.active,paused:state.paused,gameOver:state.gameOver,camera:{...camera},
      houseCount:state.houses.length,population:state.villagers.length,populationCapacity:state.houses.length*HOUSE_CAPACITY,
      houses:state.houses.map(h=>({id:h.id,x:h.x,y:h.y,tx:h.tx,ty:h.ty,residents:homePopulation(h)})),
      conversationsStarted:state.conversationsStarted,conversationsCompleted:state.conversationsCompleted,
      conversationDurations:[...state.conversationDurations],
      villagers:state.villagers.map(v=>({id:v.id,gender:v.gender,x:v.x,y:v.y,tx:v.tx,ty:v.ty,
        movingTo:v.moveTo?{...v.moveTo}:null,dir:v.dir,mode:v.mode,action:v.action,
        chatPartner:v.partnerId,chatRemaining:v.chatTime,chatDuration:v.chatDuration,homeId:v.homeId}))}),
    place:(type,x,y)=>TOWERS[type]?placeTower(type,x,y):false,
    npcSpriteInfo:()=>Object.fromEntries(Object.entries(NPC_SPECS).map(([gender,s])=>
      [gender,{walkFrames:s.walk.frames,walkFps:NPC_WALK_FPS,drawHeight:NPC_DRAW_HEIGHT,
        emotes:s.emotes.poses.length,loaded:['walk','emotes','idle'].every(t=>Boolean(npcImages[gender][t]))}])),
    startWave:()=>startWave(),reset:()=>reset(),
    buildHouse:(x,y)=>buildHouse(x,y),
    poseVillager:(id,pose)=>{const v=state.villagers.find(v=>v.id===id);return triggerNpcPose(v,pose);},
    center:()=>{camera.x=C;camera.y=C;}
  });
  generateWorld();loadSprites();loadNpcImages();reset();
  requestAnimationFrame((t)=>{lastFrame=t;requestAnimationFrame(frame);});
})();
