// v0.3.1: 고화소 픽셀 원본. 이 경로만 교체하면 새 채팅에서 제작한 PNG를 적용할 수 있습니다.
// 스프라이트 권장 해상도: 타워 96×112 / 적 64×72 / 중앙 성 256×264.
// 이미지를 로드할 수 없을 경우 게임은 단순 코드 도트로 표시합니다.
window.PIXEL_ASSETS = {
  house_thatch: 'assets/sprites/house_thatch.png',
  castle: 'assets/sprites/castle.png',
  tower_arrow: 'assets/sprites/tower_arrow.png',
  tower_cannon: 'assets/sprites/tower_cannon.png',
  tower_frost: 'assets/sprites/tower_frost.png',
  tower_flame: 'assets/sprites/tower_flame.png',
  enemy_grunt: 'assets/sprites/enemy_grunt.png',
  enemy_runner: 'assets/sprites/enemy_runner.png',
  enemy_brute: 'assets/sprites/enemy_brute.png',
  enemy_boss: 'assets/sprites/enemy_boss.png',
  tree: 'assets/sprites/tree.png',
  rock: 'assets/sprites/rock.png',
  crystal: 'assets/sprites/crystal.png',
};
